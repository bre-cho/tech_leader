
export const FACE_BALANCE_POSITIVE_TERMS = [
  "short compact lower face",
  "soft compact oval face shape",
  "short feminine chin",
  "rounded soft chin",
  "youthful Korean facial proportions",
  "shorter nose-to-chin distance",
  "soft cheek fullness",
  "compact jawline",
  "gentle lower-face proportions",
  "balanced midface ratio",
  "soft feminine facial structure",
  "youthful compact face proportions",
  "natural Korean beauty proportions",
  "subtle cheek volume",
  "non-elongated chin structure"
];

export const FACE_BALANCE_NEGATIVE_TERMS = [
  "long chin",
  "elongated lower face",
  "anime chin",
  "pointed chin",
  "excessive V-line jaw",
  "sharp jawline",
  "horse face proportions",
  "elongated facial proportions",
  "CGI influencer face",
  "overly sculpted jaw",
  "hollow cheeks",
  "gaunt face",
  "stretched lower face",
  "exaggerated jaw contour"
];
