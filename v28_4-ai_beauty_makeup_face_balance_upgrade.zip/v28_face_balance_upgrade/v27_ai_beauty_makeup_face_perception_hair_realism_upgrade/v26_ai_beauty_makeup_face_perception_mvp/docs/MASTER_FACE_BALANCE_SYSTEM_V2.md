
# MASTER FACE BALANCE SYSTEM V2

## Positive Prompt
- short compact lower face
- soft compact oval face shape
- short feminine chin
- rounded soft chin
- youthful Korean facial proportions
- shorter nose-to-chin distance
- soft cheek fullness
- compact jawline
- gentle lower-face proportions
- balanced midface ratio
- soft feminine facial structure
- youthful compact face proportions
- natural Korean beauty proportions
- subtle cheek volume
- non-elongated chin structure

## Core Face Fix Combo
- short compact lower face
- short feminine chin
- rounded soft chin
- shorter nose-to-chin distance
- soft cheek fullness
- non-elongated chin structure

## Negative Prompt
- long chin
- elongated lower face
- anime chin
- pointed chin
- excessive V-line jaw
- sharp jawline
- horse face proportions
- elongated facial proportions
- CGI influencer face
- overly sculpted jaw
- hollow cheeks
- gaunt face
- stretched lower face
- exaggerated jaw contour

## Result Goal
- compact Korean beauty face
- youthful lower-face balance
- soft jawline realism
- shorter chin proportions
- approachable K-beauty softness
