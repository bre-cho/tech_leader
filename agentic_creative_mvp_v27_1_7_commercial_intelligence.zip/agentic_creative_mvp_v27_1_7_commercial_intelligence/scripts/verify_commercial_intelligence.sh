#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../backend"
python -m compileall app
python -m pytest tests -q
