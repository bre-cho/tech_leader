from fastapi import FastAPI
from app.api.v1.commercial_intelligence import router as commercial_router

app = FastAPI(title='AI Commercial Creative Infrastructure MVP', version='v27.1-v27.7')
app.include_router(commercial_router)

@app.get('/health')
def health():
    return {'ok': True, 'version': 'v27.1-v27.7-commercial-intelligence'}
