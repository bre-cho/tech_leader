# V27.1 → V27.7 Commercial Creative Intelligence Patch

## Purpose
This patch upgrades the MVP from poster/image generation into **AI Commercial Creative Infrastructure**.

It adds real runtime logic for:
- V27.1 Attention Routing Engine
- V27.2 Typography Hierarchy Engine
- V27.3 Product Hero Engine
- V27.4 Environment Reaction Engine
- V27.5 Commercial Psychology Engine
- V27.6 Billboard & Print Engine
- V27.7 Category Commercial Engine

## Runtime Flow
```text
Commercial Input
→ Category Commercial Engine
→ Attention Routing Engine
→ Typography Hierarchy Engine
→ Product Hero Engine
→ Environment Reaction Engine
→ Commercial Psychology Engine
→ Billboard / Print Engine
→ Prompt Compiler
→ Commercial Scoring
→ QA / Promotion Gate
→ Winner DNA Candidate
→ Storyboard Expansion
```

## API
```http
POST /api/v1/commercial-intelligence/reason
```

Example:
```json
{
  "brand_name": "IceFresh",
  "product_name": "Cooling Shampoo",
  "category": "sports_grooming",
  "audience": "young active men",
  "business_goal": "conversion",
  "product_benefits": ["cooling freshness", "anti-dandruff confidence"],
  "export_targets": ["billboard", "tiktok"],
  "product_materials": ["plastic", "liquid"],
  "sensory_effect": "cooling airflow",
  "price_tier": "premium"
}
```

## Dev Patch Steps
1. Copy `backend/app/commercial_intelligence` into the MVP backend.
2. Copy `backend/app/api/v1/commercial_intelligence.py`.
3. Include router in `backend/app/main.py`.
4. Copy frontend page/components if using Next.js.
5. Run:
```bash
pip install -r backend/requirements.txt
bash scripts/verify_commercial_intelligence.sh
uvicorn app.main:app --reload --app-dir backend
```

## Why this is not a skeleton
Each engine has deterministic business logic:
- attention route by category and conversion goal
- typography rules for social/billboard/print
- product material and packshot rules
- environment physics response
- emotion → perception → category mapping
- export/readability constraints
- scoring and QA gate
- Winner DNA candidate generation

## Integration with V27 HiDream
The `prompt` output should feed the existing V27 HiDream provider adapter.
Use this commercial reasoning layer before calling `local_diffusers`, `hf_inference`, or premium render provider.

## Promotion Gate
`qa.promotion_status` can be used by existing Promotion Gate.
- `APPROVED`: allow final render / publish
- `NEEDS_REVISION`: rerun planner or adjust route/category/typography

## Winner DNA
If `winner_dna.store_candidate = true`, push it to the Winner DNA memory engine.
