'use client';
import { useState } from 'react';
import { CommercialReasoningPanel } from '../../components/commercial/CommercialReasoningPanel';

export default function CommercialCreativePage(){
  const [result,setResult]=useState<any>(null); const [loading,setLoading]=useState(false);
  async function run(){
    setLoading(true);
    const payload={brand_name:'Lumi',product_name:'Gold Serum',category:'beauty',audience:'premium skincare buyers',business_goal:'conversion',product_benefits:['glowing skin','hydration','premium texture'],export_targets:['social','print'],product_materials:['glass','liquid'],price_tier:'luxury'};
    const r=await fetch('/api/v1/commercial-intelligence/reason',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    setResult(await r.json()); setLoading(false);
  }
  return <main className="min-h-screen bg-neutral-950 text-white p-8">
    <div className="max-w-6xl mx-auto space-y-6">
      <div><p className="text-sm text-amber-300">V27.1 → V27.7</p><h1 className="text-4xl font-bold">AI Commercial Creative Infrastructure</h1><p className="text-neutral-400 mt-2">Commercial visual reasoning, attention routing, typography, product hero, psychology, billboard/print readiness.</p></div>
      <button onClick={run} className="px-5 py-3 rounded-2xl bg-amber-400 text-black font-semibold">{loading?'Đang phân tích...':'Run Commercial Reasoning'}</button>
      {result && <CommercialReasoningPanel result={result}/>} 
    </div>
  </main>
}
