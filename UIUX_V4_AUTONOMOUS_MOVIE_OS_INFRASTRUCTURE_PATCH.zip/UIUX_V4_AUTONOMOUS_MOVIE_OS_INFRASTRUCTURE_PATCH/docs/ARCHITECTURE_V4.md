# SUPERCool-Inspired Movie OS V4 Architecture

## 1. Cinematic UX Layer

Mục tiêu:
- fullscreen director interface
- emotional typography
- cinematic transitions
- immersive workspace

## 2. Creative Abstraction Layer

User chỉ nhập:

```text
dark fantasy queen cinematic trailer
```

System tự:
- hiểu ý đồ
- chia shot
- chọn lens
- chọn mood
- pacing
- soundtrack
- color
- transition

## 3. Sequential Creative Runtime

Không render từng ảnh rời rạc.

Mà:
- scene continuity
- visual rhythm
- narrative memory
- cinematic pacing
- temporal coherence

## 4. Emotion-driven Orchestration

Bao gồm:
- emotional peak graph
- tension pacing
- retention rhythm
- visual density curve
- silence/breath timing

## 5. Runtime Memory Graph

Sau mỗi movie plan, hệ thống lưu:
- mood DNA
- character DNA
- camera DNA
- rhythm DNA
- provider runtime result
- winning scene patterns

## 6. Scene Dependency Rebuilder

Nếu scene lỗi:
- xác định scene phụ thuộc
- rebuild scene lỗi
- rebuild affected range nếu continuity bị ảnh hưởng
- giữ max_concurrent_render = 1
