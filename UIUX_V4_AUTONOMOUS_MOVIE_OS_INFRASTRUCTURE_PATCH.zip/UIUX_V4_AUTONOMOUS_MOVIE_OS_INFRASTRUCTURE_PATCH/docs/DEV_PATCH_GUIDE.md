# DEV PATCH GUIDE

## 1. Tạo branch

```bash
git checkout -b feature/movie-os-v4-autonomous-infrastructure
```

## 2. Copy backend

```bash
cp -r backend/app/movie_os_v4 <your_backend>/app/
cp backend/app/api/routes/movie_os_v4.py <your_backend>/app/api/routes/
```

## 3. Gắn router

Trong `main.py` hoặc `api_router.py`:

```python
from app.api.routes.movie_os_v4 import router as movie_os_v4_router
app.include_router(movie_os_v4_router, prefix="/api/v1")
```

## 4. Copy Next.js

```bash
cp -r frontend-next/app/movie-os-v4 <next_root>/app/
cp -r frontend-next/components/movie-os-v4 <next_root>/components/
cp frontend-next/types/movie-os-v4.ts <next_root>/types/
```

## 5. Copy Vite

```bash
cp frontend-vite/src/pages/AutonomousMovieStudioV4.tsx <vite_root>/src/pages/
cp -r frontend-vite/src/movie-os-v4 <vite_root>/src/
cp frontend-vite/src/styles/movie-os-v4.css <vite_root>/src/styles/
```

## 6. Test backend

```bash
curl -X POST http://localhost:8000/api/v1/movie-os-v4/direct \
  -H "Content-Type: application/json" \
  -d '{
    "prompt":"dark fantasy queen cinematic trailer",
    "target_duration":60,
    "provider":"kling",
    "planned_batch_size":6
  }'
```

Kết quả phải có:

```text
director_brief
narrative_graph
mood_profile
character_bible
shot_plan
emotional_timeline
storyboard
scene_dependency_graph
sequential_runtime_plan
editor_plan
assembly_plan
memory_update
```

## 7. Test rebuild scene

```bash
curl -X POST http://localhost:8000/api/v1/movie-os-v4/rebuild-scene \
  -H "Content-Type: application/json" \
  -d '{
    "scene_index":3,
    "reason":"provider failed",
    "dependency_policy":"rebuild_scene_only"
  }'
```

## 8. Production hardening

Sau khi UI chạy ổn, tạo DB models:

```text
MovieProjectV4
DirectorBrief
NarrativeNode
MoodProfile
CharacterBible
ShotPlanItem
EmotionalTimelinePoint
StoryboardScene
SceneDependency
SequentialRenderStep
EditorPlan
AssemblyPlan
MemoryGraphNode
MemoryGraphEdge
RuntimeEvent
```

## 9. Luật render

```text
planned_batch_size = nhóm kế hoạch
max_concurrent_render = 1
execution_mode = sequential
```

Không render nhiều cảnh cùng lúc.
