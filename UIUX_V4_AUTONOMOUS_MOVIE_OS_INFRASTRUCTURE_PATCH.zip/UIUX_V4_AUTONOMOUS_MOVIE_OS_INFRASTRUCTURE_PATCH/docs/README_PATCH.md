# UIUX_V4_AUTONOMOUS_MOVIE_OS_INFRASTRUCTURE_PATCH

## Mục tiêu

Nâng cấp MVP thành:

```text
SUPERCool-Inspired Movie OS V4
```

Đây không còn là AI image/video tool, mà là:

```text
Autonomous AI Film Production Infrastructure
```

## Luồng V4

```text
User Prompt
→ AI Director Brief
→ Narrative Intent Graph
→ Mood + Color + Lens Engine
→ Character Bible
→ Shot Language Planner
→ Emotional Timeline Graph
→ Storyboard Runtime
→ Scene Dependency Graph
→ Sequential Provider Runtime
→ AI Editor
→ Final Movie Assembly
→ Memory Graph Update
```

## Điểm khác biệt quan trọng

Không render từng ảnh rời rạc.

Mà render theo:

```text
một dòng thời gian điện ảnh có trí nhớ
```

Nghĩa là:
- có Character Bible
- có scene dependency
- có temporal coherence
- có emotional timeline
- có rebuild scene lỗi
- có memory graph update
- có sequential render runtime

## Module backend mới

```text
backend/app/movie_os_v4/
  schemas.py
  ai_director_brief.py
  creative_abstraction_layer.py
  mood_color_lens_engine.py
  character_continuity_runtime.py
  shot_language_planner.py
  emotional_timeline_graph.py
  story_rhythm_intelligence.py
  scene_dependency_rebuilder.py
  temporal_coherence_guard.py
  runtime_memory_graph.py
  sequential_creative_runtime.py
  ai_editor.py
  final_movie_assembly.py
  autonomous_movie_orchestrator.py

backend/app/api/routes/movie_os_v4.py
```

## Frontend mới

```text
frontend-next/app/movie-os-v4/
frontend-next/components/movie-os-v4/
frontend-next/types/movie-os-v4.ts

frontend-vite/src/pages/AutonomousMovieStudioV4.tsx
frontend-vite/src/movie-os-v4/
frontend-vite/src/styles/movie-os-v4.css
```

## API mới

```text
POST /api/v1/movie-os-v4/direct
POST /api/v1/movie-os-v4/rebuild-scene
GET  /api/v1/movie-os-v4/taxonomy
```

## Cách áp dụng

### Backend

Copy:

```text
backend/app/movie_os_v4
backend/app/api/routes/movie_os_v4.py
```

Gắn router:

```python
from app.api.routes.movie_os_v4 import router as movie_os_v4_router
app.include_router(movie_os_v4_router, prefix="/api/v1")
```

### Next.js

Copy:

```text
frontend-next/app/movie-os-v4
frontend-next/components/movie-os-v4
frontend-next/types/movie-os-v4.ts
```

Mở:

```text
http://localhost:3000/movie-os-v4
```

### Vite

Copy:

```text
frontend-vite/src/pages/AutonomousMovieStudioV4.tsx
frontend-vite/src/movie-os-v4
frontend-vite/src/styles/movie-os-v4.css
```

Render page `AutonomousMovieStudioV4`.
