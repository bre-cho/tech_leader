from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./beauty_intelligence.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

class BeautyRun(Base):
    __tablename__ = "beauty_runs"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, unique=True, index=True)
    source_path = Column(String)
    output_path = Column(String)
    mode = Column(String)
    preset = Column(String)
    analysis_json = Column(Text)
    reasoning_json = Column(Text)
    qa_json = Column(Text)
    score = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)

class BeautyMemory(Base):
    __tablename__ = "beauty_memory"
    id = Column(Integer, primary_key=True)
    brand_name = Column(String, index=True)
    persona = Column(String, index=True)
    preset = Column(String)
    beauty_dna_json = Column(Text)
    performance_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=datetime.utcnow)

class BeautyGraphEdge(Base):
    __tablename__ = "beauty_graph_edges"
    id = Column(Integer, primary_key=True)
    source = Column(String, index=True)
    relation = Column(String, index=True)
    target = Column(String, index=True)
    weight = Column(Float, default=0.5)
    evidence = Column(Text, default="")
    observations = Column(Integer, default=1)
    updated_at = Column(DateTime, default=datetime.utcnow)

def init_db():
    Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
