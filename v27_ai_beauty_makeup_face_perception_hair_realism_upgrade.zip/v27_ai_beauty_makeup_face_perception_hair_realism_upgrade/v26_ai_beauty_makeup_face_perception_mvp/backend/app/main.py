from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import router
from app.db import init_db
from app.seed import seed_graph

app = FastAPI(
    title="V26 AI Beauty / Makeup / Face Perception Intelligence",
    version="1.0.0",
    description="AI Beauty Intelligence Infrastructure, not a makeup filter."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db()
    seed_graph()

app.include_router(router, prefix="/api/v1")
