class ContourHighlightEngine:
    def reason(self, geometry, persona):
        if not geometry.get("available"):
            return {"available": False, "zones": [], "reason": "no face geometry"}
        face_shape = geometry["face_shape"]
        zones = []
        if face_shape == "round":
            zones += [
                {"zone": "jawline", "method": "soft contour", "perception": "slimmer face perception"},
                {"zone": "side_cheeks", "method": "subtle shadow", "perception": "reduced width"},
                {"zone": "center_face", "method": "highlight", "perception": "brightened center"},
            ]
        elif face_shape == "long":
            zones += [
                {"zone": "forehead_top", "method": "soft shadow", "perception": "balanced face length"},
                {"zone": "chin_tip", "method": "soft shadow", "perception": "shorter face perception"},
                {"zone": "cheek_center", "method": "highlight", "perception": "freshness"},
            ]
        else:
            zones += [
                {"zone": "cheekbone", "method": "natural contour", "perception": "lifted structure"},
                {"zone": "nose_bridge", "method": "thin highlight", "perception": "clean center line"},
                {"zone": "center_face", "method": "soft highlight", "perception": "premium skin"},
            ]
        if persona in ["luxury_editorial", "kol_beauty"]:
            zones.append({"zone": "outer_face", "method": "cool soft shadow", "perception": "editorial luxury depth"})
        return {
            "available": True,
            "face_shape": face_shape,
            "zones": zones,
            "rules": [
                "light color → bring forward",
                "dark color → reduce / slim",
                "highlight center face → brighten perception",
                "contour jawline → slimmer face perception",
            ]
        }
