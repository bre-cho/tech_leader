from PIL import Image, ImageFilter

class BeautyExportEngine:
    def export(self, img: Image.Image, scale: str):
        targets = {"preview": None, "2k": 2048, "4k": 4096, "8k": 7680}
        long_edge = targets.get(scale)
        w,h = img.size
        out = img
        upscaled = False
        if long_edge and max(w,h) < long_edge:
            ratio = long_edge / max(w,h)
            out = img.resize((int(w*ratio), int(h*ratio)), Image.Resampling.LANCZOS)
            out = out.filter(ImageFilter.UnsharpMask(radius=0.8, percent=80, threshold=3))
            upscaled = True
        return out, {
            "scale": scale,
            "size": list(out.size),
            "upscaled": upscaled,
            "outputs": ["beauty preview", "social KOL asset", "campaign poster", "4K/8K luxury render"],
        }
