from pathlib import Path
from PIL import Image
import hashlib

STORAGE = Path("storage")
UPLOADS = STORAGE / "uploads"
OUTPUTS = STORAGE / "outputs"
for p in [UPLOADS, OUTPUTS]:
    p.mkdir(parents=True, exist_ok=True)

def save_upload(file_bytes: bytes, filename: str) -> str:
    digest = hashlib.sha256(file_bytes).hexdigest()[:16]
    ext = Path(filename).suffix.lower() or ".jpg"
    path = UPLOADS / f"{digest}{ext}"
    path.write_bytes(file_bytes)
    return str(path)

def load_image(path: str) -> Image.Image:
    return Image.open(path).convert("RGB")

def save_image(img: Image.Image, run_id: str, stage: str) -> str:
    path = OUTPUTS / f"{run_id}_{stage}.jpg"
    img.save(path, quality=95, subsampling=0)
    return str(path)
