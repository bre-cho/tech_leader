class BeautyPerceptionScoring:
    def score(self, skin, geometry, contour, transfer, neutralization, persona):
        scores = {
            "luxury_perception": 55.0,
            "softness": 55.0,
            "confidence": 55.0,
            "youthfulness": 55.0,
            "executive_beauty": 50.0,
            "wedding_emotion": 50.0,
            "identity_safety": 85.0 if transfer["semantic_layers"]["identity_preservation"] else 35.0,
            "skin_realism": 86.0 if skin["context"] == "visible_skin" else 65.0,
        }
        mood = transfer.get("mood","")
        if "luxury" in mood or "editorial" in mood:
            scores["luxury_perception"] += 22
            scores["confidence"] += 12
        if "soft" in mood or "bridal" in mood:
            scores["softness"] += 20
            scores["wedding_emotion"] += 22
        if "clinical" in mood or "trust" in mood:
            scores["executive_beauty"] += 16
        if "fresh" in mood or persona == "tiktok_creator":
            scores["youthfulness"] += 18
        if contour.get("available"):
            scores["confidence"] += 8
        if neutralization["corrections"]:
            scores["skin_realism"] += 5
        return {k: min(100.0, round(v, 2)) for k,v in scores.items()}
