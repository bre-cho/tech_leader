from PIL import Image
import numpy as np

class FaceAnalysisEngine:
    def analyze(self, img: Image.Image):
        w, h = img.size
        arr = np.asarray(img).astype("float32")
        skin_mask = self._skin_mask(arr)
        skin_ratio = float(skin_mask.mean())
        # MVP face box heuristic: center portrait area when skin exists
        face_box = {
            "x": round(w * 0.25), "y": round(h * 0.12),
            "width": round(w * 0.50), "height": round(h * 0.58),
        } if skin_ratio > 0.03 else None
        return {
            "has_face_probability": round(min(1.0, skin_ratio * 5), 3),
            "skin_visibility_ratio": round(skin_ratio, 4),
            "face_box": face_box,
            "identity_policy": "preserve face structure; do not replace identity",
        }, skin_mask

    def _skin_mask(self, arr):
        r,g,b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
        return (r > 75) & (g > 38) & (b > 28) & (r > g) & (g >= b * 0.75) & ((r - b) > 12)

class SkinToneIntelligenceEngine:
    def analyze(self, img: Image.Image, skin_mask):
        arr = np.asarray(img).astype("float32")
        if skin_mask.mean() < 0.01:
            avg = arr.reshape(-1,3).mean(axis=0)
            context = "low_skin_visibility"
        else:
            avg = arr[skin_mask].mean(axis=0)
            context = "visible_skin"
        r,g,b = avg
        warmth = float((r - b) / 255.0)
        undertone = "warm" if warmth > 0.12 else "neutral" if warmth > 0.04 else "cool"
        brightness = float(avg.mean()/255.0)
        skin_depth = "light" if brightness > 0.68 else "medium" if brightness > 0.42 else "deep"
        return {
            "context": context,
            "average_rgb": [round(float(x),2) for x in avg],
            "undertone": undertone,
            "skin_depth": skin_depth,
            "rules": [
                "protect natural Asian/Vietnamese skin undertone",
                "avoid plastic skin",
                "preserve pores and micro texture",
                "foundation transfer must not erase identity",
            ]
        }

class FacialGeometryEngine:
    def analyze(self, face_analysis):
        box = face_analysis.get("face_box")
        if not box:
            return {"available": False, "reason": "no confident face region"}
        ratio = box["height"] / max(1, box["width"])
        face_shape = "oval" if 1.1 <= ratio <= 1.45 else "long" if ratio > 1.45 else "round"
        return {
            "available": True,
            "face_shape": face_shape,
            "jawline": "soft" if face_shape in ["oval", "round"] else "defined",
            "cheekbone": "balanced",
            "nose_bridge": "center highlight zone",
            "forehead": "upper highlight / oil-control zone",
            "chin": "lower balance zone",
            "eye_spacing": "balanced",
            "lip_proportion": "medium",
            "perception_rules": [
                "light color brings forward",
                "dark color reduces/slims",
                "highlight center face brightens perception",
                "contour jawline creates slimmer face perception",
            ]
        }
