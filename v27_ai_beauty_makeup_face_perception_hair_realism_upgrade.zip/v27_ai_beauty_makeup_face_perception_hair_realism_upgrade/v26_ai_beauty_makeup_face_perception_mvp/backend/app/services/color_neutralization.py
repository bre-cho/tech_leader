import numpy as np

class ColorNeutralizationGraph:
    def analyze(self, img, skin_mask):
        arr = np.asarray(img).astype("float32")
        regions = []
        if skin_mask.mean() > 0.01:
            skin = arr[skin_mask]
            avg = skin.mean(axis=0)
            r,g,b = avg
            redness = max(0, (r - g) / 255.0)
            yellow = max(0, ((r + g)/2 - b) / 255.0)
            darkness = max(0, 0.55 - skin.mean()/255.0)
            if redness > 0.08:
                regions.append(self._item("redness", "green", min(0.55, redness * 1.8), "cheeks"))
            if darkness > 0.12:
                regions.append(self._item("purple_dark_circle", "orange/peach", min(0.50, darkness * 1.4), "under_eye"))
            if yellow > 0.18:
                regions.append(self._item("yellow_dullness", "purple", min(0.42, yellow * 0.9), "overall_skin"))
            if not regions:
                regions.append(self._item("minor_dullness", "pink brightening", 0.18, "center_face"))
        return {
            "principle": "opposite colors neutralize visible skin discoloration",
            "corrections": regions,
            "graph": [
                "redness → green corrector",
                "purple/dark circle → orange/peach corrector",
                "yellow dullness → purple corrector",
                "darkness/dull skin → pink brightening",
            ]
        }

    def _item(self, defect, corrector, strength, region):
        return {
            "defect_color": defect,
            "opposite_corrector": corrector,
            "correction_strength": round(float(strength), 3),
            "skin_preservation": True,
            "region": region,
        }
