class BeautyQAEngine:
    def check(self, face, skin, transfer, perception):
        checks = {
            "face_detected_or_safe_fallback": face["has_face_probability"] > 0.05 or face["face_box"] is None,
            "identity_preservation": transfer["semantic_layers"]["identity_preservation"] is True,
            "not_instagram_filter": transfer["policy"] == "semantic makeup transfer, not whole-image filter",
            "skin_texture_protected": transfer["semantic_layers"]["texture_protection"] is True,
            "skin_realism_score": perception["skin_realism"] >= 70,
            "identity_safety_score": perception["identity_safety"] >= 80,
        }
        score = round(sum(checks.values()) / len(checks) * 100, 2)
        return {
            "passed": score >= 85,
            "score": score,
            "checks": checks,
            "issues": [k for k,v in checks.items() if not v],
            "rules": [
                "không đổi danh tính",
                "không plastic skin",
                "không filter toàn ảnh",
                "makeup transfer theo vùng: foundation, lips, eyeshadow, blush, illumination",
                "preserve skin texture and face proportions",
            ]
        }
