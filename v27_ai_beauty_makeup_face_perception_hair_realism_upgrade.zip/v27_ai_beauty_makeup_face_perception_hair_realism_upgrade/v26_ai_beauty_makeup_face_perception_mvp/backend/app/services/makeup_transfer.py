from PIL import Image, ImageEnhance, ImageFilter
import numpy as np
from app.services.presets import PRESETS

class SemanticMakeupTransferEngine:
    def transfer(self, img: Image.Image, preset_name: str, strength: float, skin_mask, face_analysis, identity_preservation=True):
        preset = PRESETS.get(preset_name, PRESETS["soft_glam"])
        arr = np.asarray(img).astype("float32")
        out = arr.copy()

        # foundation transfer on skin only
        if skin_mask.mean() > 0.01:
            foundation = np.array(preset["foundation"], dtype="float32")
            out[skin_mask] = out[skin_mask] * (1 - 0.25 * strength) + (out[skin_mask] * foundation) * (0.25 * strength)

        h, w = arr.shape[:2]
        box = face_analysis.get("face_box")
        region_report = {}
        if box:
            x,y,bw,bh = box["x"], box["y"], box["width"], box["height"]
            # lips approximate region
            lx1, lx2 = int(x + bw*0.35), int(x + bw*0.65)
            ly1, ly2 = int(y + bh*0.68), int(y + bh*0.80)
            out[ly1:ly2, lx1:lx2] = self._tint(out[ly1:ly2, lx1:lx2], preset["lip"], 0.45 * strength)
            region_report["lip_color_transfer"] = {"region": [lx1, ly1, lx2, ly2], "enabled": True}

            # blush approximate
            for side in [0.22, 0.68]:
                cx1, cx2 = int(x + bw*side), int(x + bw*(side+0.18))
                cy1, cy2 = int(y + bh*0.45), int(y + bh*0.60)
                out[cy1:cy2, cx1:cx2] = self._tint(out[cy1:cy2, cx1:cx2], preset["blush"], 0.22 * strength)
            region_report["blush_transfer"] = {"enabled": True}

            # eyeshadow approximate
            ex1, ex2 = int(x + bw*0.22), int(x + bw*0.78)
            ey1, ey2 = int(y + bh*0.28), int(y + bh*0.42)
            out[ey1:ey2, ex1:ex2] = self._tint(out[ey1:ey2, ex1:ex2], preset["shadow"], 0.18 * strength)
            region_report["eyeshadow_transfer"] = {"enabled": True}

        result = Image.fromarray(np.clip(out, 0, 255).astype("uint8"))
        result = ImageEnhance.Brightness(result).enhance(1 + (preset["brightness"] - 1) * strength)
        result = ImageEnhance.Contrast(result).enhance(1 + (preset["contrast"] - 1) * strength)
        # preserve detail
        result = result.filter(ImageFilter.UnsharpMask(radius=0.8, percent=60, threshold=3))

        return result, {
            "preset": preset_name,
            "mood": preset["mood"],
            "semantic_layers": {
                "foundation_transfer": True,
                "lip_color_transfer": region_report.get("lip_color_transfer", {"enabled": False}),
                "eyeshadow_transfer": region_report.get("eyeshadow_transfer", {"enabled": False}),
                "blush_transfer": region_report.get("blush_transfer", {"enabled": False}),
                "illumination_transfer": True,
                "texture_protection": True,
                "identity_preservation": identity_preservation,
            },
            "policy": "semantic makeup transfer, not whole-image filter",
        }

    def _tint(self, region, factors, alpha):
        return region * (1 - alpha) + (region * np.array(factors, dtype="float32")) * alpha
