from app.db import SessionLocal, BeautyGraphEdge

EDGES = [
    ("contour:jawline", "increases", "face_slim_perception", 0.86, "dark contour reduces perceived width"),
    ("highlight:center_face", "increases", "premium_skin_perception", 0.82, "light brings facial center forward"),
    ("warm_tone", "increases", "emotional_warmth", 0.78, "warm tones soften and humanize beauty"),
    ("cool_tone", "increases", "luxury_perception", 0.74, "cool controlled tone supports editorial luxury"),
    ("lip_color:rose", "increases", "confidence_perception", 0.80, "rose/nude lip reads wearable and confident"),
    ("green_corrector", "neutralizes", "redness", 0.93, "opposite color correction"),
    ("peach_corrector", "neutralizes", "purple_dark_circle", 0.91, "orange/peach neutralizes purple-blue darkness"),
    ("purple_corrector", "neutralizes", "yellow_dullness", 0.88, "purple balances yellow undertone"),
    ("pink_brightening", "improves", "dull_skin", 0.79, "pink adds healthy brightness"),
]

def seed_graph():
    db = SessionLocal()
    try:
        if db.query(BeautyGraphEdge).count() == 0:
            for s, r, t, w, e in EDGES:
                db.add(BeautyGraphEdge(source=s, relation=r, target=t, weight=w, evidence=e))
            db.commit()
    finally:
        db.close()
