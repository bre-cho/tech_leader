import json
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.db import get_db, BeautyRun, BeautyMemory, BeautyGraphEdge
from app.schemas import BeautyOptions, BeautyMetricUpdate
from app.workflow import BeautyIntelligenceWorkflow

router = APIRouter()

@router.get("/health")
def health():
    return {"status": "ok", "module": "V26 AI Beauty / Makeup / Face Perception Intelligence"}

@router.post("/beauty/analyze")
async def analyze(
    file: UploadFile = File(...),
    brand_name: str = Form("default"),
    persona: str = Form("personal_beauty"),
    preset: str = Form("soft_glam"),
    db: Session = Depends(get_db),
):
    data = await file.read()
    options = BeautyOptions(brand_name=brand_name, persona=persona, mode="analyze", preset=preset, export_scale="preview")
    return BeautyIntelligenceWorkflow().run(db, data, file.filename or "beauty.jpg", options)

@router.post("/beauty/transfer")
async def transfer(
    file: UploadFile = File(...),
    brand_name: str = Form("default"),
    persona: str = Form("kol_beauty"),
    preset: str = Form("soft_glam"),
    strength: float = Form(0.6),
    skin_preservation: bool = Form(True),
    identity_preservation: bool = Form(True),
    export_scale: str = Form("4k"),
    db: Session = Depends(get_db),
):
    data = await file.read()
    options = BeautyOptions(
        brand_name=brand_name,
        persona=persona,
        mode="analyze_transfer",
        preset=preset,
        strength=strength,
        skin_preservation=skin_preservation,
        identity_preservation=identity_preservation,
        export_scale=export_scale,
    )
    return BeautyIntelligenceWorkflow().run(db, data, file.filename or "beauty.jpg", options)

@router.post("/beauty/contour")
async def contour(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await file.read()
    options = BeautyOptions(mode="contour", export_scale="preview")
    return BeautyIntelligenceWorkflow().run(db, data, file.filename or "beauty.jpg", options)

@router.post("/beauty/skin-tone")
async def skin_tone(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await file.read()
    options = BeautyOptions(mode="skin_tone", export_scale="preview")
    return BeautyIntelligenceWorkflow().run(db, data, file.filename or "beauty.jpg", options)

@router.post("/beauty/perception")
async def perception(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await file.read()
    options = BeautyOptions(mode="perception", export_scale="preview")
    return BeautyIntelligenceWorkflow().run(db, data, file.filename or "beauty.jpg", options)

@router.get("/beauty/runs/{run_id}")
def get_run(run_id: str, db: Session = Depends(get_db)):
    row = db.query(BeautyRun).filter(BeautyRun.run_id == run_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="run not found")
    return {
        "run_id": row.run_id,
        "source_path": row.source_path,
        "output_path": row.output_path,
        "mode": row.mode,
        "preset": row.preset,
        "analysis": json.loads(row.analysis_json),
        "reasoning": json.loads(row.reasoning_json),
        "qa": json.loads(row.qa_json),
        "score": row.score,
    }

@router.get("/beauty/files")
def get_file(path: str):
    return FileResponse(path)

@router.get("/beauty/memory/{brand_name}")
def get_memory(brand_name: str, db: Session = Depends(get_db)):
    rows = db.query(BeautyMemory).filter(BeautyMemory.brand_name == brand_name).order_by(BeautyMemory.id.desc()).limit(30).all()
    return {"items": [{
        "id": r.id,
        "persona": r.persona,
        "preset": r.preset,
        "beauty_dna": json.loads(r.beauty_dna_json),
        "performance": json.loads(r.performance_json),
    } for r in rows]}

@router.get("/beauty/graph")
def graph(db: Session = Depends(get_db)):
    rows = db.query(BeautyGraphEdge).order_by(BeautyGraphEdge.weight.desc()).limit(100).all()
    return {"items": [{
        "source": r.source, "relation": r.relation, "target": r.target,
        "weight": r.weight, "evidence": r.evidence, "observations": r.observations
    } for r in rows]}

@router.post("/beauty/metrics")
def metrics(payload: BeautyMetricUpdate, db: Session = Depends(get_db)):
    row = db.query(BeautyRun).filter(BeautyRun.run_id == payload.run_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="run not found")
    memory = BeautyMemory(
        brand_name="performance_update",
        persona="compound_learning",
        preset=row.preset,
        beauty_dna_json=row.reasoning_json,
        performance_json=json.dumps(payload.model_dump(), ensure_ascii=False),
    )
    db.add(memory)
    db.commit()
    return {"saved": True, "compound_beauty_learning": True, "performance": payload.model_dump()}
