import json, uuid
from sqlalchemy.orm import Session
from app.db import BeautyRun, BeautyMemory
from app.schemas import BeautyOptions
from app.services.io import save_upload, load_image, save_image
from app.services.analyzers import FaceAnalysisEngine, SkinToneIntelligenceEngine, FacialGeometryEngine
from app.services.color_neutralization import ColorNeutralizationGraph
from app.services.contour import ContourHighlightEngine
from app.services.makeup_transfer import SemanticMakeupTransferEngine
from app.services.perception import BeautyPerceptionScoring
from app.services.exporter import BeautyExportEngine
from app.services.qa import BeautyQAEngine

class BeautyIntelligenceWorkflow:
    def run(self, db: Session, file_bytes: bytes, filename: str, options: BeautyOptions):
        run_id = "beauty_" + uuid.uuid4().hex[:12]
        source_path = save_upload(file_bytes, filename)
        img = load_image(source_path)

        face, skin_mask = FaceAnalysisEngine().analyze(img)
        skin = SkinToneIntelligenceEngine().analyze(img, skin_mask)
        geometry = FacialGeometryEngine().analyze(face)
        neutralization = ColorNeutralizationGraph().analyze(img, skin_mask)
        contour = ContourHighlightEngine().reason(geometry, options.persona)

        working = img
        transfer_report = {
            "preset": options.preset,
            "semantic_layers": {
                "foundation_transfer": False,
                "lip_color_transfer": {"enabled": False},
                "eyeshadow_transfer": {"enabled": False},
                "blush_transfer": {"enabled": False},
                "illumination_transfer": False,
                "texture_protection": options.skin_preservation,
                "identity_preservation": options.identity_preservation,
            },
            "policy": "analysis only",
            "mood": "none",
        }

        if options.mode in ["transfer", "analyze_transfer"]:
            working, transfer_report = SemanticMakeupTransferEngine().transfer(
                img, options.preset, options.strength, skin_mask, face, options.identity_preservation
            )

        perception = BeautyPerceptionScoring().score(skin, geometry, contour, transfer_report, neutralization, options.persona)
        qa = BeautyQAEngine().check(face, skin, transfer_report, perception)
        exported, export = BeautyExportEngine().export(working, options.export_scale)
        output_path = save_image(exported, run_id, "final")

        reasoning = {
            "face_analysis": face,
            "skin_tone": skin,
            "facial_geometry": geometry,
            "color_neutralization": neutralization,
            "contour_highlight": contour,
            "makeup_transfer": transfer_report,
            "beauty_perception": perception,
            "export": export,
        }

        score = round((sum(perception.values()) / len(perception) + qa["score"]) / 2, 2)
        row = BeautyRun(
            run_id=run_id,
            source_path=source_path,
            output_path=output_path,
            mode=options.mode,
            preset=options.preset,
            analysis_json=json.dumps({"face": face, "skin": skin, "geometry": geometry}, ensure_ascii=False),
            reasoning_json=json.dumps(reasoning, ensure_ascii=False),
            qa_json=json.dumps(qa, ensure_ascii=False),
            score=score,
        )
        db.add(row)

        memory = BeautyMemory(
            brand_name=options.brand_name,
            persona=options.persona,
            preset=options.preset,
            beauty_dna_json=json.dumps({
                "skin_tone": skin,
                "face_shape": geometry.get("face_shape"),
                "neutralization": neutralization,
                "contour": contour,
                "preset": options.preset,
                "perception": perception,
                "score": score,
            }, ensure_ascii=False),
            performance_json=json.dumps({"initial_score": score, "run_id": run_id}, ensure_ascii=False),
        )
        db.add(memory)
        db.commit()

        return {
            "run_id": run_id,
            "source_path": source_path,
            "output_path": output_path,
            "face_analysis": face,
            "skin_tone": skin,
            "facial_geometry": geometry,
            "color_neutralization": neutralization,
            "contour_highlight": contour,
            "makeup_transfer": transfer_report,
            "beauty_perception": perception,
            "qa": qa,
            "export": export,
            "memory_update": {"saved": True, "brand_name": options.brand_name, "beauty_infrastructure": True},
        }
