from typing import Any, Dict, Optional
from pydantic import BaseModel, Field

class BeautyOptions(BaseModel):
    brand_name: str = "default"
    persona: str = "personal_beauty"  # personal_beauty | kol_beauty | wedding | studio_makeup | spa | cosmetic_brand | beauty_clinic | tiktok_creator
    mode: str = "analyze_transfer"  # analyze | transfer | contour | skin_tone | perception | analyze_transfer
    preset: str = "soft_glam"  # natural_clean | soft_glam | korean_bridal | luxury_editorial | clinic_trust | tiktok_fresh
    strength: float = Field(default=0.6, ge=0.0, le=1.0)
    skin_preservation: bool = True
    identity_preservation: bool = True
    export_scale: str = "4k"  # preview | 2k | 4k | 8k

class BeautyResponse(BaseModel):
    run_id: str
    source_path: str
    output_path: str
    face_analysis: Dict[str, Any]
    skin_tone: Dict[str, Any]
    facial_geometry: Dict[str, Any]
    color_neutralization: Dict[str, Any]
    contour_highlight: Dict[str, Any]
    makeup_transfer: Dict[str, Any]
    beauty_perception: Dict[str, Any]
    qa: Dict[str, Any]
    export: Dict[str, Any]
    memory_update: Dict[str, Any]

class BeautyMetricUpdate(BaseModel):
    run_id: str
    luxury_score: float = 0
    confidence_score: float = 0
    conversion_rate: float = 0
    client_acceptance: float = 0
