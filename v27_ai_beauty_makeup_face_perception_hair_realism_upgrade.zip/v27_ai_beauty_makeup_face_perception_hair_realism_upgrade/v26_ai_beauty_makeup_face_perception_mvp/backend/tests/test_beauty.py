from fastapi.testclient import TestClient
from app.main import app
from PIL import Image, ImageDraw
import io

client = TestClient(app)

def make_face():
    img = Image.new("RGB", (512, 512), (220, 200, 185))
    d = ImageDraw.Draw(img)
    d.ellipse((150,80,360,350), fill=(205,155,125))
    d.ellipse((205,170,225,190), fill=(30,30,30))
    d.ellipse((285,170,305,190), fill=(30,30,30))
    d.ellipse((230,260,285,280), fill=(150,70,80))
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    buf.seek(0)
    return buf

def test_beauty_transfer():
    res = client.post(
        "/api/v1/beauty/transfer",
        files={"file": ("face.jpg", make_face(), "image/jpeg")},
        data={"brand_name": "Demo Beauty", "persona": "kol_beauty", "preset": "soft_glam", "export_scale": "preview"},
    )
    assert res.status_code == 200
    data = res.json()
    assert data["qa"]["passed"] is True
    assert "color_neutralization" in data
    assert data["makeup_transfer"]["policy"] == "semantic makeup transfer, not whole-image filter"

def test_beauty_graph():
    res = client.get("/api/v1/beauty/graph")
    assert res.status_code == 200
    assert len(res.json()["items"]) > 0
