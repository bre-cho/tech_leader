# V26 AI Beauty / Makeup / Face Perception Intelligence — Dev Patch Guide

## Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
pytest -q
```

## Frontend

```bash
cd frontend
npm install
NEXT_PUBLIC_API_BASE=http://localhost:8000 npm run dev
```

Open:

```text
/beauty-intelligence
```

## APIs

```text
POST /api/v1/beauty/analyze
POST /api/v1/beauty/transfer
POST /api/v1/beauty/contour
POST /api/v1/beauty/skin-tone
POST /api/v1/beauty/perception
GET  /api/v1/beauty/graph
GET  /api/v1/beauty/memory/{brand_name}
POST /api/v1/beauty/metrics
```

## Production upgrade points

- Replace heuristic face box with MediaPipe / face parsing.
- Replace semantic regions with segmentation masks.
- Connect real makeup transfer model.
- Connect Color Intelligence Graph, Blend Retouch Engine, Restore Photo Engine and 8K Upscale Runtime.
