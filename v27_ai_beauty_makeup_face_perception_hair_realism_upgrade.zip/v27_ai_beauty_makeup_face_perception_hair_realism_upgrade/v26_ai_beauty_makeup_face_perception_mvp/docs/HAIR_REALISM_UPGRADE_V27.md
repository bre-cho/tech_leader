# V27 — AI Beauty Makeup Face Perception + Hair Realism Upgrade

## Mục tiêu
Nâng cấp MVP `v26_ai_beauty_makeup_face_perception_real_mvp` bằng bộ `STORYBOARD_160_SCENES_MASTER_HAIR_REALISM_V2`.

Patch này thêm một lớp vận hành thật cho phần tóc của người mẫu ảo KOL:

- tự động thêm prompt tóc thật vào mọi scene
- chống tóc nhựa, tóc bệt, tóc CGI
- chấm điểm chất lượng tóc trước khi render
- lưu metadata tóc vào artifact
- hỗ trợ SDXL / Flux / HiDream / Veo / Runway / Kling
- có API, thư viện lõi, UI panel và test

## Global Positive Prompt
```text
ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K
```

## Core Hair Realism Combo
```text
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness
```

## Global Negative Prompt
```text
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo
```

## Quy tắc vận hành
- `hair_realism_score >= 90`: Winner — được phép lưu Winner DNA
- `hair_realism_score >= 80`: Good — được phép render
- `hair_realism_score 70–79`: Cần tối ưu thêm
- `< 70`: Chặn render, không gửi provider

## Các file chính đã thêm
```txt
src/lib/beauty-intelligence/hair-realism/
  storyboard160.ts
  hairProfiles.ts
  hairPromptEngine.ts
  hairScoring.ts
  providerHairAdapters.ts
  types.ts
  index.ts

src/app/api/beauty/hair-realism/score/route.ts
src/components/beauty-intelligence/hair-realism/HairRealismPanel.tsx
tests/beauty-intelligence/hair-realism/hairScoring.test.ts
docs/STORYBOARD_160_SCENES_MASTER_HAIR_REALISM_V2.md
```

## Cách tích hợp vào pipeline render
```ts
import { enhanceScenePromptWithHairRealism } from "@/lib/beauty-intelligence/hair-realism";

const enhanced = enhanceScenePromptWithHairRealism({
  sceneId: scene.id,
  basePrompt: scene.prompt,
  negativePrompt: scene.negativePrompt,
  provider: selectedProvider,
  sceneType: scene.sceneType,
  camera: scene.camera,
  lighting: scene.lighting,
});

if (enhanced.score.total < 80) {
  throw new Error("Hair realism score thấp, không gửi provider.");
}

scene.prompt = enhanced.prompt;
scene.negativePrompt = enhanced.negativePrompt;
scene.metadata = {
  ...scene.metadata,
  hairRealism: enhanced.score,
  hairModules: enhanced.appliedModules,
};
```
