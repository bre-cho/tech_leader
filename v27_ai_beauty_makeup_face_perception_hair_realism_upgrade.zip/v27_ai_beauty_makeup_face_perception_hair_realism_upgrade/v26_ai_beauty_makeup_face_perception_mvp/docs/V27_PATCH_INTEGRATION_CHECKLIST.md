# V27 Patch Integration Checklist

## Copy files
- [ ] `src/lib/beauty-intelligence/hair-realism`
- [ ] `src/app/api/beauty/hair-realism/score/route.ts`
- [ ] `src/components/beauty-intelligence/hair-realism/HairRealismPanel.tsx`
- [ ] `docs/STORYBOARD_160_SCENES_MASTER_HAIR_REALISM_V2.md`

## Wire into render pipeline
- [ ] Call `enhanceScenePromptWithHairRealism()` before provider dispatch
- [ ] Save `hairRealism.score` into artifact metadata
- [ ] Block render when `score.total < 80`
- [ ] Mark scene as Winner DNA candidate when `score.total >= 90`

## Provider-specific checks
- [ ] SDXL: RAW beauty photography + DSLR realism
- [ ] Flux: micro strand detail + realistic strand separation
- [ ] HiDream: cinematic hair micro texture realism
- [ ] Veo: natural hair motion physics + realistic strand simulation
- [ ] Runway/Kling: temporal hair consistency

## QA
- [ ] Test close-up portrait
- [ ] Test overhead carpet shot
- [ ] Test runway spotlight shot
- [ ] Test mirror reflection shot
- [ ] Ensure no plastic hair / helmet hair / melted strands
