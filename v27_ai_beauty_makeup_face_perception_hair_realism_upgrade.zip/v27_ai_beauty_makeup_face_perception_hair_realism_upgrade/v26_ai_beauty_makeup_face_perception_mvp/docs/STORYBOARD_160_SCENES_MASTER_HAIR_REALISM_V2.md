# STORYBOARD 160 SCENES — MASTER HAIR REALISM V2

## GLOBAL POSITIVE PROMPT

ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

## CORE HAIR REALISM COMBO

extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

## GLOBAL NEGATIVE PROMPT

plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

---

SCENE 001

Scene Type:
hero portrait

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 002

Scene Type:
overhead carpet shot

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 003

Scene Type:
mirror reflection scene

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 004

Scene Type:
runway spotlight scene

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 005

Scene Type:
beauty macro shot

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 006

Scene Type:
window sunlight portrait

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 007

Scene Type:
fashion cardigan movement shot

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 008

Scene Type:
pastel vanity lifestyle scene

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 009

Scene Type:
cream sofa cinematic shot

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 010

Scene Type:
close-up eye contact beauty portrait

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 011

Scene Type:
hero portrait

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 012

Scene Type:
overhead carpet shot

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 013

Scene Type:
mirror reflection scene

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 014

Scene Type:
runway spotlight scene

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 015

Scene Type:
beauty macro shot

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 016

Scene Type:
window sunlight portrait

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 017

Scene Type:
fashion cardigan movement shot

Camera:
cinematic close-up

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, cinematic close-up, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 018

Scene Type:
pastel vanity lifestyle scene

Camera:
overhead top-down angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, overhead top-down angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 019

Scene Type:
cream sofa cinematic shot

Camera:
side profile angle

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, side profile angle, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 020

Scene Type:
close-up eye contact beauty portrait

Camera:
85mm beauty portrait lens

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, 85mm beauty portrait lens, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 021

Scene Type:
hero portrait

Camera:
soft tracking shot

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, soft tracking shot, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 022

Scene Type:
overhead carpet shot

Camera:
front-facing beauty angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, front-facing beauty angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 023

Scene Type:
mirror reflection scene

Camera:
mirror reflection composition

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, mirror reflection composition, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 024

Scene Type:
runway spotlight scene

Camera:
wide cinematic composition

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, wide cinematic composition, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 025

Scene Type:
beauty macro shot

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 026

Scene Type:
window sunlight portrait

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 027

Scene Type:
fashion cardigan movement shot

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 028

Scene Type:
pastel vanity lifestyle scene

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 029

Scene Type:
cream sofa cinematic shot

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 030

Scene Type:
close-up eye contact beauty portrait

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 031

Scene Type:
hero portrait

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 032

Scene Type:
overhead carpet shot

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 033

Scene Type:
mirror reflection scene

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 034

Scene Type:
runway spotlight scene

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 035

Scene Type:
beauty macro shot

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 036

Scene Type:
window sunlight portrait

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 037

Scene Type:
fashion cardigan movement shot

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 038

Scene Type:
pastel vanity lifestyle scene

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 039

Scene Type:
cream sofa cinematic shot

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 040

Scene Type:
close-up eye contact beauty portrait

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 041

Scene Type:
hero portrait

Camera:
cinematic close-up

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, cinematic close-up, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 042

Scene Type:
overhead carpet shot

Camera:
overhead top-down angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, overhead top-down angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 043

Scene Type:
mirror reflection scene

Camera:
side profile angle

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, side profile angle, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 044

Scene Type:
runway spotlight scene

Camera:
85mm beauty portrait lens

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, 85mm beauty portrait lens, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 045

Scene Type:
beauty macro shot

Camera:
soft tracking shot

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, soft tracking shot, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 046

Scene Type:
window sunlight portrait

Camera:
front-facing beauty angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, front-facing beauty angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 047

Scene Type:
fashion cardigan movement shot

Camera:
mirror reflection composition

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, mirror reflection composition, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 048

Scene Type:
pastel vanity lifestyle scene

Camera:
wide cinematic composition

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, wide cinematic composition, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 049

Scene Type:
cream sofa cinematic shot

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 050

Scene Type:
close-up eye contact beauty portrait

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 051

Scene Type:
hero portrait

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 052

Scene Type:
overhead carpet shot

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 053

Scene Type:
mirror reflection scene

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 054

Scene Type:
runway spotlight scene

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 055

Scene Type:
beauty macro shot

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 056

Scene Type:
window sunlight portrait

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 057

Scene Type:
fashion cardigan movement shot

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 058

Scene Type:
pastel vanity lifestyle scene

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 059

Scene Type:
cream sofa cinematic shot

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 060

Scene Type:
close-up eye contact beauty portrait

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 061

Scene Type:
hero portrait

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 062

Scene Type:
overhead carpet shot

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 063

Scene Type:
mirror reflection scene

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 064

Scene Type:
runway spotlight scene

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 065

Scene Type:
beauty macro shot

Camera:
cinematic close-up

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, cinematic close-up, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 066

Scene Type:
window sunlight portrait

Camera:
overhead top-down angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, overhead top-down angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 067

Scene Type:
fashion cardigan movement shot

Camera:
side profile angle

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, side profile angle, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 068

Scene Type:
pastel vanity lifestyle scene

Camera:
85mm beauty portrait lens

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, 85mm beauty portrait lens, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 069

Scene Type:
cream sofa cinematic shot

Camera:
soft tracking shot

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, soft tracking shot, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 070

Scene Type:
close-up eye contact beauty portrait

Camera:
front-facing beauty angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, front-facing beauty angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 071

Scene Type:
hero portrait

Camera:
mirror reflection composition

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, mirror reflection composition, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 072

Scene Type:
overhead carpet shot

Camera:
wide cinematic composition

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, wide cinematic composition, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 073

Scene Type:
mirror reflection scene

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 074

Scene Type:
runway spotlight scene

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 075

Scene Type:
beauty macro shot

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 076

Scene Type:
window sunlight portrait

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 077

Scene Type:
fashion cardigan movement shot

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 078

Scene Type:
pastel vanity lifestyle scene

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 079

Scene Type:
cream sofa cinematic shot

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 080

Scene Type:
close-up eye contact beauty portrait

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 081

Scene Type:
hero portrait

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 082

Scene Type:
overhead carpet shot

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 083

Scene Type:
mirror reflection scene

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 084

Scene Type:
runway spotlight scene

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 085

Scene Type:
beauty macro shot

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 086

Scene Type:
window sunlight portrait

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 087

Scene Type:
fashion cardigan movement shot

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 088

Scene Type:
pastel vanity lifestyle scene

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 089

Scene Type:
cream sofa cinematic shot

Camera:
cinematic close-up

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, cinematic close-up, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 090

Scene Type:
close-up eye contact beauty portrait

Camera:
overhead top-down angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, overhead top-down angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 091

Scene Type:
hero portrait

Camera:
side profile angle

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, side profile angle, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 092

Scene Type:
overhead carpet shot

Camera:
85mm beauty portrait lens

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, 85mm beauty portrait lens, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 093

Scene Type:
mirror reflection scene

Camera:
soft tracking shot

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, soft tracking shot, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 094

Scene Type:
runway spotlight scene

Camera:
front-facing beauty angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, front-facing beauty angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 095

Scene Type:
beauty macro shot

Camera:
mirror reflection composition

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, mirror reflection composition, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 096

Scene Type:
window sunlight portrait

Camera:
wide cinematic composition

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, wide cinematic composition, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 097

Scene Type:
fashion cardigan movement shot

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 098

Scene Type:
pastel vanity lifestyle scene

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 099

Scene Type:
cream sofa cinematic shot

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 100

Scene Type:
close-up eye contact beauty portrait

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 101

Scene Type:
hero portrait

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 102

Scene Type:
overhead carpet shot

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 103

Scene Type:
mirror reflection scene

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 104

Scene Type:
runway spotlight scene

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 105

Scene Type:
beauty macro shot

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 106

Scene Type:
window sunlight portrait

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 107

Scene Type:
fashion cardigan movement shot

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 108

Scene Type:
pastel vanity lifestyle scene

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 109

Scene Type:
cream sofa cinematic shot

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 110

Scene Type:
close-up eye contact beauty portrait

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 111

Scene Type:
hero portrait

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 112

Scene Type:
overhead carpet shot

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 113

Scene Type:
mirror reflection scene

Camera:
cinematic close-up

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, cinematic close-up, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 114

Scene Type:
runway spotlight scene

Camera:
overhead top-down angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, overhead top-down angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 115

Scene Type:
beauty macro shot

Camera:
side profile angle

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, side profile angle, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 116

Scene Type:
window sunlight portrait

Camera:
85mm beauty portrait lens

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, 85mm beauty portrait lens, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 117

Scene Type:
fashion cardigan movement shot

Camera:
soft tracking shot

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, soft tracking shot, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 118

Scene Type:
pastel vanity lifestyle scene

Camera:
front-facing beauty angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, front-facing beauty angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 119

Scene Type:
cream sofa cinematic shot

Camera:
mirror reflection composition

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, mirror reflection composition, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 120

Scene Type:
close-up eye contact beauty portrait

Camera:
wide cinematic composition

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, wide cinematic composition, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 121

Scene Type:
hero portrait

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 122

Scene Type:
overhead carpet shot

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 123

Scene Type:
mirror reflection scene

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 124

Scene Type:
runway spotlight scene

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 125

Scene Type:
beauty macro shot

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 126

Scene Type:
window sunlight portrait

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 127

Scene Type:
fashion cardigan movement shot

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 128

Scene Type:
pastel vanity lifestyle scene

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 129

Scene Type:
cream sofa cinematic shot

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 130

Scene Type:
close-up eye contact beauty portrait

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 131

Scene Type:
hero portrait

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 132

Scene Type:
overhead carpet shot

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 133

Scene Type:
mirror reflection scene

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 134

Scene Type:
runway spotlight scene

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 135

Scene Type:
beauty macro shot

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 136

Scene Type:
window sunlight portrait

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 137

Scene Type:
fashion cardigan movement shot

Camera:
cinematic close-up

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, cinematic close-up, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 138

Scene Type:
pastel vanity lifestyle scene

Camera:
overhead top-down angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, overhead top-down angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 139

Scene Type:
cream sofa cinematic shot

Camera:
side profile angle

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, side profile angle, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 140

Scene Type:
close-up eye contact beauty portrait

Camera:
85mm beauty portrait lens

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, 85mm beauty portrait lens, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 141

Scene Type:
hero portrait

Camera:
soft tracking shot

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, soft tracking shot, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 142

Scene Type:
overhead carpet shot

Camera:
front-facing beauty angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, front-facing beauty angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 143

Scene Type:
mirror reflection scene

Camera:
mirror reflection composition

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, mirror reflection composition, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 144

Scene Type:
runway spotlight scene

Camera:
wide cinematic composition

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, wide cinematic composition, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 145

Scene Type:
beauty macro shot

Camera:
cinematic close-up

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, cinematic close-up, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 146

Scene Type:
window sunlight portrait

Camera:
overhead top-down angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, overhead top-down angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 147

Scene Type:
fashion cardigan movement shot

Camera:
side profile angle

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, side profile angle, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 148

Scene Type:
pastel vanity lifestyle scene

Camera:
85mm beauty portrait lens

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, 85mm beauty portrait lens, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 149

Scene Type:
cream sofa cinematic shot

Camera:
soft tracking shot

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, soft tracking shot, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 150

Scene Type:
close-up eye contact beauty portrait

Camera:
front-facing beauty angle

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, front-facing beauty angle, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 151

Scene Type:
hero portrait

Camera:
mirror reflection composition

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, hero portrait, mirror reflection composition, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 152

Scene Type:
overhead carpet shot

Camera:
wide cinematic composition

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, overhead carpet shot, wide cinematic composition, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 153

Scene Type:
mirror reflection scene

Camera:
cinematic close-up

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, mirror reflection scene, cinematic close-up, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 154

Scene Type:
runway spotlight scene

Camera:
overhead top-down angle

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, runway spotlight scene, overhead top-down angle, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 155

Scene Type:
beauty macro shot

Camera:
side profile angle

Lighting:
cinematic runway spotlight

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, beauty macro shot, side profile angle, cinematic runway spotlight, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 156

Scene Type:
window sunlight portrait

Camera:
85mm beauty portrait lens

Lighting:
golden hour beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, window sunlight portrait, 85mm beauty portrait lens, golden hour beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 157

Scene Type:
fashion cardigan movement shot

Camera:
soft tracking shot

Lighting:
warm pastel sunlight diffusion

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, fashion cardigan movement shot, soft tracking shot, warm pastel sunlight diffusion, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 158

Scene Type:
pastel vanity lifestyle scene

Camera:
front-facing beauty angle

Lighting:
high-key cinematic beauty lighting

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, pastel vanity lifestyle scene, front-facing beauty angle, high-key cinematic beauty lighting, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 159

Scene Type:
cream sofa cinematic shot

Camera:
mirror reflection composition

Lighting:
luxury skincare glow

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, cream sofa cinematic shot, mirror reflection composition, luxury skincare glow, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---

SCENE 160

Scene Type:
close-up eye contact beauty portrait

Camera:
wide cinematic composition

Lighting:
soft cinematic shadows

Prompt:
adult virtual Korean beauty influencer, soft feminine beauty, warm approachable smile, bright almond eyes, glossy natural lips, elegant soft jawline, white sporty bra top, white fitted shorts, thin transparent white cardigan, luxury TikTok beauty commerce aesthetic, close-up eye contact beauty portrait, wide cinematic composition, soft cinematic shadows, ultra realistic Korean beauty influencer, luxury beauty commercial photography, extremely realistic individual hair strands, visible natural hair fiber texture, ultra detailed separated hair strands, realistic messy bun hairstyle, soft layered updo, natural baby hairs around forehead and cheeks, loose face-framing strands, physically accurate hair lighting, cinematic strand reflections, soft anisotropic hair highlights, natural hair density variation, realistic hair volume gradient, multi-tone warm brown hair color, subtle caramel highlights, deep natural hair shadows, ultra fine flyaway hairs, realistic imperfect hairline, shallow depth of field, realistic foreground strand sharpness, cinematic beauty lighting, glowing realistic skin texture, micro skin pores, soft feminine expression, DSLR photography realism, ultra detailed beauty portrait, luxury K-beauty campaign aesthetic, ultra realistic, 8K

Negative Prompt:
plastic hair, helmet hair, AI hair texture, melted hair strands, blurry hair, wax hair, solid hair mass, low detail hair, fake wig texture, overly smooth hair, CGI hair, perfect symmetry hair, stiff hair, duplicate strands, fuzzy hair edges, artificial hairline, blurry face, plastic skin, over-smoothed skin, AI artifacts, watermark, text, logo

Hair Realism Lock:
extremely realistic individual hair strands
visible natural hair fiber texture
natural baby hairs around forehead and cheeks
ultra fine flyaway hairs
physically accurate hair lighting
realistic foreground strand sharpness

---
