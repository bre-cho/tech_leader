import { enhanceScenePromptWithHairRealism, scoreHairRealismPrompt } from "../../../src/lib/beauty-intelligence/hair-realism";

describe("Hair Realism Engine V2", () => {
  it("enhances scene prompt with required hair realism terms", () => {
    const result = enhanceScenePromptWithHairRealism({
      sceneId: 1,
      basePrompt: "adult virtual Korean beauty influencer",
      provider: "flux",
      strictGate: true
    });

    expect(result.prompt).toContain("extremely realistic individual hair strands");
    expect(result.prompt).toContain("visible natural hair fiber texture");
    expect(result.prompt).toContain("natural baby hairs around forehead and cheeks");
    expect(result.prompt).toContain("physically accurate hair lighting");
    expect(result.negativePrompt).toContain("plastic hair");
    expect(result.score.total).toBeGreaterThanOrEqual(80);
    expect(result.gatePassed).toBe(true);
  });

  it("fails weak prompt score", () => {
    const score = scoreHairRealismPrompt("beautiful model with nice hair", "");
    expect(score.total).toBeLessThan(70);
    expect(score.grade).toBe("FAIL");
  });
});
