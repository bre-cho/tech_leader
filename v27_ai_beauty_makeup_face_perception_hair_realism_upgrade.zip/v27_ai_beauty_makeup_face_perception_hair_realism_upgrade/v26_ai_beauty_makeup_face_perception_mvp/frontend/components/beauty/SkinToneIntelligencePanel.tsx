export default function SkinToneIntelligencePanel(){return null}
