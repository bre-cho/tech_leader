export default function LuxuryBeautyRenderPanel(){return null}
