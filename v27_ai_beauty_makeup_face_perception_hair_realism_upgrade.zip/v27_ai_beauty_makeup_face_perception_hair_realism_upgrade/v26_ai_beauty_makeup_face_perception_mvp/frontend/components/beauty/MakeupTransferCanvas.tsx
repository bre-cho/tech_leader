export default function MakeupTransferCanvas(){return null}
