export default function BeautyColorWheel(){return null}
