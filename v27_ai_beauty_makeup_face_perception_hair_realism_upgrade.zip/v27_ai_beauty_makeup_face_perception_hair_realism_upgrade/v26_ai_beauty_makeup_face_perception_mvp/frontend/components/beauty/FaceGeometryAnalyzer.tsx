export default function FaceGeometryAnalyzer(){return null}
