import BeautyPerceptionStudio from "../../components/beauty/BeautyPerceptionStudio";
export default function Page() {
  return <BeautyPerceptionStudio />;
}
