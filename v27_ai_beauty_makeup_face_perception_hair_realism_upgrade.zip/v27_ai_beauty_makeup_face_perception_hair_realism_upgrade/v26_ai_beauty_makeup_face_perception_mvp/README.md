# V26 AI Beauty / Makeup / Face Perception Intelligence MVP

Runnable MVP for AI-Native Beauty & Perception Operating System.

## Run backend

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## Run frontend

```bash
cd frontend
npm install
NEXT_PUBLIC_API_BASE=http://localhost:8000 npm run dev
```

## Verify

```bash
./scripts/verify.sh
```
