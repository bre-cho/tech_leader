from typing import Any, Literal
from pydantic import BaseModel, Field

class ProductHoldingAvatarRequest(BaseModel):
    industry: str = Field(..., min_length=2)
    product_name: str = Field(..., min_length=2)
    product_type: str = Field(..., min_length=2)
    brand_name: str = ""
    target_channel: Literal["poster", "tiktok", "reel", "livestream", "landing", "ecommerce", "campaign"] = "tiktok"
    avatar_gender: Literal["female", "male", "non_binary"] = "female"
    avatar_style: str = "young premium beauty KOL, realistic, trustworthy, commercial fashion"
    outfit_type: Literal["tshirt", "bikini", "fashion", "wedding_dress", "spa_uniform", "lookbook"] = "tshirt"
    product_motion_goal: str = "introduce, hold, try-on, demonstrate benefits, call to action"
    campaign_goal: str = "increase trust, attention, product desire, and conversion"
    language: str = "vi"

class ProductHoldingAvatarResponse(BaseModel):
    module: str
    avatar_profile: dict[str, Any]
    product_understanding: dict[str, Any]
    body_language_plan: list[dict[str, Any]]
    facial_consistency: dict[str, Any]
    beauty_perception_scoring: dict[str, Any]
    natural_curve_engine: dict[str, Any]
    fashion_perception: dict[str, Any]
    camera_pose_plan: dict[str, Any]
    fabric_physics: dict[str, Any]
    body_beauty_graph: dict[str, Any]
    poster_prompt: str
    video_showcase_storyboard: list[dict[str, Any]]
    qa_contract: dict[str, Any]
    system_integrations: list[str]
    market_targets: list[str]
