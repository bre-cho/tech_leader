from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.schemas.beauty_avatar import ProductHoldingAvatarRequest


PRODUCT_HOLDING_RULES: dict[str, dict[str, str]] = {
    "lipstick": {"pose": "hold near lips", "gesture": "micro turn to product then smile to camera", "benefit_focus": "shade payoff and confidence"},
    "serum": {"pose": "hold near cheek or chest-level product hero", "gesture": "gaze follows bottle lift, then eye contact", "benefit_focus": "glow, skin care, trust"},
    "perfume": {"pose": "hold near neck or shoulder", "gesture": "soft wrist rotation, elegant smile", "benefit_focus": "luxury scent and lifestyle"},
    "cream": {"pose": "hold jar with two hands", "gesture": "bring product forward, open palm support", "benefit_focus": "texture, care, premium"},
    "palette": {"pose": "open palette toward camera", "gesture": "point to colors, glance at palette", "benefit_focus": "color choice and makeup versatility"},
    "default": {"pose": "hold product at chest-to-face zone", "gesture": "show product, turn body slightly, smile", "benefit_focus": "clear product visibility and credibility"},
}

OUTFIT_PERCEPTION: dict[str, dict[str, Any]] = {
    "tshirt": {
        "perception": "softness, casual attractiveness, approachable beauty commerce",
        "silhouette_rule": "tasteful fitted commercial t-shirt, realistic chest balance, moderated neckline, brand-safe framing",
        "fabric": "cotton tension, natural folds, subtle compression, no plastic body",
    },
    "bikini": {
        "perception": "body balance, confidence, elegance",
        "silhouette_rule": "swimwear commercial styling, realistic anatomy, no exaggerated proportions",
        "fabric": "elastic stretch, edge tension, realistic gravity",
    },
    "fashion": {
        "perception": "editorial fashion, confidence, luxury silhouette",
        "silhouette_rule": "fashion-commercial pose, natural torso twist, natural proportions",
        "fabric": "tailored fabric flow, folds, material response",
    },
    "wedding_dress": {
        "perception": "femininity, softness, luxury, wedding emotion",
        "silhouette_rule": "romantic bridal silhouette, graceful posture, premium fabric layering",
        "fabric": "silk flow, lace texture, layered dress gravity",
    },
    "spa_uniform": {
        "perception": "premium wellness, care, calm trust",
        "silhouette_rule": "clean uniform fit, professional warmth, non-seductive trust styling",
        "fabric": "soft uniform folds, clean lines, wellness texture",
    },
    "lookbook": {
        "perception": "campaign-ready fashion, product catalog consistency",
        "silhouette_rule": "consistent catalog poses with natural variation",
        "fabric": "repeatable fabric physics across batch outputs",
    },
}


@dataclass
class ProductHoldingAvatarEngine:
    """V26.2 AI Beauty Avatar Commerce Engine.

    This engine turns a virtual avatar into a product-holding KOL model that can
    produce still ads and video storyboards. It is intentionally brand-safe:
    body and outfit rules optimize commercial silhouette, realism, confidence,
    and persuasion without explicit framing or unrealistic anatomy.
    """

    def build(self, request: ProductHoldingAvatarRequest) -> dict[str, Any]:
        product = self._understand_product(request.product_type, request.product_name)
        avatar = self._build_avatar_profile(request)
        body_language = self._build_body_language_sequence(product)
        consistency = self._facial_consistency_contract()
        beauty_score = self._beauty_perception_scoring(request, product)
        natural_curve = self._natural_curve_engine(request.outfit_type)
        fashion = self._fashion_perception_engine(request.outfit_type)
        camera = self._camera_pose_engine(request.target_channel)
        fabric = self._fabric_physics_engine(request.outfit_type)
        graph = self._body_beauty_graph()
        poster_prompt = self._compile_poster_prompt(request, avatar, product, body_language, natural_curve, camera, fabric)
        storyboard = self._compile_video_storyboard(request, product, body_language, camera)
        qa = self._qa_contract()

        return {
            "module": "V26.2_PRODUCT_HOLDING_TRY_ON_AVATAR_ENGINE",
            "avatar_profile": avatar,
            "product_understanding": product,
            "body_language_plan": body_language,
            "facial_consistency": consistency,
            "beauty_perception_scoring": beauty_score,
            "natural_curve_engine": natural_curve,
            "fashion_perception": fashion,
            "camera_pose_plan": camera,
            "fabric_physics": fabric,
            "body_beauty_graph": graph,
            "poster_prompt": poster_prompt,
            "video_showcase_storyboard": storyboard,
            "qa_contract": qa,
            "system_integrations": [
                "Beauty Perception Intelligence",
                "Color Intelligence Graph",
                "Blend Retouch Engine",
                "Restore Photo Engine",
                "Fashion Uniform Builder",
                "3D Brand Space Builder",
                "Creative Execution Graph",
                "8K Upscale Runtime",
                "Brand Memory Cloud",
                "Winner DNA Engine",
            ],
            "market_targets": [
                "beauty creator economy",
                "wedding industry",
                "spa ecosystem",
                "beauty clinic",
                "cosmetic brands",
                "fashion brands",
                "virtual influencers",
                "AI KOLs",
                "beauty commerce",
                "TikTok beauty commerce",
                "livestream commerce",
                "swimwear brands",
                "fitness brands",
            ],
        }

    def _understand_product(self, product_type: str, product_name: str) -> dict[str, Any]:
        key = product_type.lower().strip()
        rule = PRODUCT_HOLDING_RULES.get(key, PRODUCT_HOLDING_RULES["default"])
        return {
            "product_name": product_name,
            "product_type": key,
            "holding_pose": rule["pose"],
            "gesture_strategy": rule["gesture"],
            "benefit_focus": rule["benefit_focus"],
            "visibility_rules": [
                "product must stay readable and non-deformed",
                "logo/label area must face camera when possible",
                "hand grip must not hide key product shape",
                "product lighting must match face and background lighting",
            ],
        }

    def _build_avatar_profile(self, request: ProductHoldingAvatarRequest) -> dict[str, Any]:
        return {
            "default_gender": request.avatar_gender,
            "style": request.avatar_style,
            "identity_lock": True,
            "commercial_safety": "adult-looking avatar, brand-safe fashion-commerce framing",
            "beauty_dna": {
                "same_face": True,
                "same_identity": True,
                "same_beauty_dna": True,
                "same_proportions": True,
                "same_perception": True,
            },
            "default_outfit": request.outfit_type,
            "default_outfit_rule": OUTFIT_PERCEPTION[request.outfit_type]["silhouette_rule"],
        }

    def _build_body_language_sequence(self, product: dict[str, Any]) -> list[dict[str, Any]]:
        return [
            {
                "step": 1,
                "name": "open_attention",
                "eyes": "direct eye contact with camera",
                "smile": "natural confident smile",
                "hands": "product visible but relaxed",
                "movement": "slight torso angle, not standing stiff",
                "purpose": "create trust and human presence",
            },
            {
                "step": 2,
                "name": "product_focus_shift",
                "eyes": "gaze follows the product as it moves upward or closer",
                "smile": "soft smile, credible demonstration",
                "hands": product["gesture_strategy"],
                "movement": "micro step or shoulder shift to create presenter dynamics",
                "purpose": "make product movement feel human and intentional",
            },
            {
                "step": 3,
                "name": "benefit_explanation",
                "eyes": "alternate between product and viewer",
                "smile": "warm persuasive expression",
                "hands": "one hand holds product, other hand points or opens palm",
                "movement": "slight torso twist and product turn toward camera",
                "purpose": "increase comprehension and persuasion",
            },
            {
                "step": 4,
                "name": "try_on_or_demo",
                "eyes": "look at application zone, then return to camera",
                "smile": "subtle satisfaction reaction",
                "hands": "controlled try-on gesture, no product deformation",
                "movement": "gentle lean-in for close-up product moment",
                "purpose": "simulate real product use",
            },
            {
                "step": 5,
                "name": "cta_close",
                "eyes": "strong direct eye contact",
                "smile": "confident closing smile",
                "hands": "product hero pose close to face/chest zone with readable label",
                "movement": "settle into final hero pose",
                "purpose": "clear call-to-action and final memory anchor",
            },
        ]

    def _facial_consistency_contract(self) -> dict[str, Any]:
        return {
            "engine": "FACIAL_CONSISTENCY_ENGINE",
            "must_preserve": ["same face", "same identity", "same beauty DNA", "same proportions", "same perception"],
            "applies_to": ["image", "video", "campaign", "TikTok", "wedding", "poster", "lookbook"],
            "checks": [
                "face embedding similarity >= configured threshold",
                "eye/nose/mouth geometry drift under threshold",
                "skin tone remains within brand/avatar DNA range",
                "makeup may change, identity must not change",
                "pose may change, facial identity must remain stable",
            ],
        }

    def _beauty_perception_scoring(self, request: ProductHoldingAvatarRequest, product: dict[str, Any]) -> dict[str, Any]:
        return {
            "engine": "BEAUTY_PERCEPTION_SCORING",
            "dimensions": {
                "luxury_perception": 9.2 if request.target_channel in {"campaign", "landing"} else 8.7,
                "softness": 9.0,
                "confidence": 9.4,
                "editorial_fashion": 8.8 if request.outfit_type in {"fashion", "lookbook", "bikini"} else 8.1,
                "young_perception": 8.9,
                "executive_beauty": 8.2,
                "wedding_emotion": 9.3 if request.outfit_type == "wedding_dress" else 7.6,
                "product_desire": 9.1,
            },
            "reasoning": f"Avatar body language, gaze tracking, and {product['holding_pose']} are optimized for product trust and desire.",
        }

    def _natural_curve_engine(self, outfit_type: str) -> dict[str, Any]:
        rule = OUTFIT_PERCEPTION[outfit_type]
        return {
            "engine": "NATURAL_CURVE_ENGINE",
            "supported_outfits": list(OUTFIT_PERCEPTION.keys()),
            "current_outfit": outfit_type,
            "rules": [
                "natural softness",
                "natural fabric tension",
                "realistic gravity",
                "commercial fashion silhouette",
                "no plastic body",
                "no unrealistic anatomy",
                "no over-inflated proportions",
            ],
            "silhouette_rule": rule["silhouette_rule"],
            "fabric_interaction": rule["fabric"],
        }

    def _fashion_perception_engine(self, outfit_type: str) -> dict[str, Any]:
        return {
            "engine": "FASHION_PERCEPTION_ENGINE",
            "current_outfit": outfit_type,
            "perception": OUTFIT_PERCEPTION[outfit_type]["perception"],
            "mapping": {k: v["perception"] for k, v in OUTFIT_PERCEPTION.items()},
        }

    def _camera_pose_engine(self, target_channel: str) -> dict[str, Any]:
        return {
            "engine": "CAMERA_AND_POSE_ENGINE",
            "recommended_lens": "85mm portrait for natural body and face compression",
            "channel": target_channel,
            "pose_rules": [
                {"rule": "low angle", "effect": "longer leg perception and stronger confidence", "use_with_care": True},
                {"rule": "85mm portrait", "effect": "natural body proportions and premium beauty feel"},
                {"rule": "slight torso twist", "effect": "slimmer waist and better silhouette"},
                {"rule": "shoulder-back posture", "effect": "better chest line and confident presenter posture, still natural"},
                {"rule": "gaze follows product motion", "effect": "human-like product demonstration"},
                {"rule": "micro movement", "effect": "avoid stiff standing presenter"},
            ],
        }

    def _fabric_physics_engine(self, outfit_type: str) -> dict[str, Any]:
        return {
            "engine": "FABRIC_PHYSICS_ENGINE",
            "current_outfit": outfit_type,
            "fabric_model": OUTFIT_PERCEPTION[outfit_type]["fabric"],
            "physics_nodes": ["cotton tension", "silk flow", "bikini stretch", "dress layering", "shirt folds", "compression zones"],
            "quality_target": "fashion-commercial-realistic, not AI fake render",
        }

    def _body_beauty_graph(self) -> dict[str, Any]:
        return {
            "engine": "BODY_BEAUTY_PERCEPTION_GRAPH",
            "nodes": [
                "Body Shape", "Chest Balance", "Waist Ratio", "Hip Ratio", "Posture", "Pose",
                "Confidence", "Elegance", "Luxury", "Femininity", "Fashion Style", "Fabric",
                "Lighting", "Camera Lens",
            ],
            "relationships": [
                {"from": "Posture", "to": "Confidence", "relation": "increases perception"},
                {"from": "Waist Ratio", "to": "Femininity", "relation": "influences perception"},
                {"from": "Fabric Tension", "to": "Realism", "relation": "increases"},
                {"from": "Lighting", "to": "Luxury Body Perception", "relation": "enhances"},
                {"from": "Pose", "to": "Elegance", "relation": "shapes"},
                {"from": "Camera Angle", "to": "Silhouette Enhancement", "relation": "controls"},
            ],
        }

    def _compile_poster_prompt(
        self,
        request: ProductHoldingAvatarRequest,
        avatar: dict[str, Any],
        product: dict[str, Any],
        body_language: list[dict[str, Any]],
        natural_curve: dict[str, Any],
        camera: dict[str, Any],
        fabric: dict[str, Any],
    ) -> str:
        return (
            f"Create a realistic commercial beauty KOL avatar poster for {request.brand_name or 'a premium brand'} "
            f"featuring an adult {avatar['default_gender']} virtual model holding {request.product_name}. "
            f"Avatar identity must remain consistent: same face, same beauty DNA, same proportions. "
            f"The model wears {request.outfit_type} with {natural_curve['silhouette_rule']}. "
            f"Use human presenter behavior: direct eye contact, gaze following product movement, natural smile, "
            f"expressive hand gestures, slight torso twist, shoulder-back confident posture, and subtle body movement. "
            f"Product pose: {product['holding_pose']}; gesture strategy: {product['gesture_strategy']}. "
            f"Camera: {camera['recommended_lens']}; fabric physics: {fabric['fabric_model']}. "
            f"Brand-safe beauty commerce style, natural anatomy, no plastic skin, no distorted hands, product label readable, "
            f"luxury beauty lighting, 8K print-ready detail."
        )

    def _compile_video_storyboard(
        self,
        request: ProductHoldingAvatarRequest,
        product: dict[str, Any],
        body_language: list[dict[str, Any]],
        camera: dict[str, Any],
    ) -> list[dict[str, Any]]:
        scenes = []
        labels = ["Hook", "Product reveal", "Benefit explanation", "Try-on/demo", "Proof/beauty reaction", "CTA close"]
        for idx, label in enumerate(labels, start=1):
            behavior = body_language[min(idx - 1, len(body_language) - 1)]
            scenes.append({
                "scene": idx,
                "title": label,
                "duration_sec": 2 if idx < 6 else 3,
                "camera": camera["recommended_lens"] if idx in {1, 6} else "medium close-up with product-safe framing",
                "eyes": behavior["eyes"],
                "smile": behavior["smile"],
                "gesture": behavior["hands"],
                "body_movement": behavior["movement"],
                "product_visibility": "product remains readable and naturally held",
                "voiceover_intent": product["benefit_focus"] if idx in {3, 4} else request.campaign_goal,
            })
        return scenes

    def _qa_contract(self) -> dict[str, Any]:
        return {
            "must_pass": [
                "facial identity consistency",
                "natural hand anatomy",
                "product not deformed",
                "product logo/label preserved when visible",
                "gaze follows product movement in demo scenes",
                "avatar does not stand stiff in all scenes",
                "smile/expression matches message intent",
                "body proportions realistic",
                "fabric physics plausible",
                "brand-safe commercial styling",
                "lighting consistent across face, body, product, and background",
            ],
            "blocked_outputs": [
                "plastic body",
                "unrealistic anatomy",
                "over-inflated proportions",
                "distorted fingers",
                "identity drift",
                "product deformation",
                "overly explicit framing",
            ],
        }
