from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    res = client.get('/api/v1/health')
    assert res.status_code == 200
    assert res.json()['status'] == 'ok'

def test_operating_law_endpoint():
    res = client.get('/api/v1/governance/operating-law')
    assert res.status_code == 200
    body = res.json()
    assert 'Workflow' in body['law']
    assert 'verify' in body['required_steps']


def test_design_studio_full_runtime():
    payload = {
        'industry': 'spa mỹ phẩm',
        'product': 'serum phục hồi da',
        'audience': 'phụ nữ 25-35',
        'channel': 'TikTok',
        'goal': 'bán hàng',
        'brand_name': 'Lumi Skin',
    }
    res = client.post('/api/v1/design-studio/run', json=payload)
    assert res.status_code == 200, res.text
    body = res.json()
    assert body['promotion_gate']['status'] == 'PASSED'
    assert body['law_trace']['verify'] is True
    assert len(body['image_concepts']) >= 3
    assert len(body['storyboard']) >= 5
    assert body['best_concept']['score']['video_upsell_ready'] is True
