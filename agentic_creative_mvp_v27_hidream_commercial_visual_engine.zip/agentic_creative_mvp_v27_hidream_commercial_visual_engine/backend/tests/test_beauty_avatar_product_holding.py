from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_product_holding_avatar_endpoint():
    payload = {
        "industry": "cosmetic brand",
        "product_name": "Luxury Rose Lipstick",
        "product_type": "lipstick",
        "brand_name": "Demo Beauty",
        "target_channel": "tiktok",
        "avatar_gender": "female",
        "outfit_type": "tshirt",
    }
    r = client.post("/api/beauty-avatar/product-holding", json=payload)
    assert r.status_code == 200
    data = r.json()
    assert data["module"] == "V26.2_PRODUCT_HOLDING_TRY_ON_AVATAR_ENGINE"
    assert data["avatar_profile"]["identity_lock"] is True
    assert "gaze follows product movement" in " ".join(data["qa_contract"]["must_pass"])
    assert len(data["video_showcase_storyboard"]) >= 5
    assert data["natural_curve_engine"]["engine"] == "NATURAL_CURVE_ENGINE"
