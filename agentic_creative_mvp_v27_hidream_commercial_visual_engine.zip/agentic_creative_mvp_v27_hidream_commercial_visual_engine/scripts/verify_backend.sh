#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../backend"
python -m compileall app
pytest -q

python -m pytest backend/tests/test_hidream_v27.py -q
