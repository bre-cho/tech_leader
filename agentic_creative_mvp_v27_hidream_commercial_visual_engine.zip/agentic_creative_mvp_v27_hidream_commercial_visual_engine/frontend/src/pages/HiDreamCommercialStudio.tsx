
import React, { useState } from 'react';
import { generateHiDreamCommercialVisual, HiDreamGenerateRequest } from '../lib/api';

const initial: HiDreamGenerateRequest = {
  business_goal: 'Create a premium cosmetic hero poster that can expand into a product showcase video',
  industry: 'cosmetic beauty',
  product_name: 'Luminous Serum',
  audience: 'young professional women who want premium glowing skin',
  use_case: 'cosmetic_product',
  aspect_ratio: '4:5',
  render_tier: 'premium',
  provider: 'mock',
  copy_text: 'Glow that feels premium',
  brand_dna: { palette: 'champagne gold, ivory, soft black', temperature: 'warm neutral luxury' },
  visual_dna: { materials: 'glass serum bottle, liquid refraction, glowing skin, silk fabric' },
  campaign_context: { offer: 'launch bundle', channel: 'TikTok + landing page' },
  enable_typography_safe_mode: true,
  enable_storyboard_expansion: true,
  enable_8k_export_contract: true,
};

export default function HiDreamCommercialStudio() {
  const [payload, setPayload] = useState<HiDreamGenerateRequest>(initial);
  const [brandDna, setBrandDna] = useState(JSON.stringify(initial.brand_dna, null, 2));
  const [visualDna, setVisualDna] = useState(JSON.stringify(initial.visual_dna, null, 2));
  const [campaignContext, setCampaignContext] = useState(JSON.stringify(initial.campaign_context, null, 2));
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function parseJson(label: string, value: string) {
    try { return JSON.parse(value || '{}'); }
    catch { throw new Error(`${label} phải là JSON hợp lệ`); }
  }

  async function submit() {
    setLoading(true); setError(''); setResult(null);
    try {
      const finalPayload = {
        ...payload,
        brand_dna: parseJson('brand_dna', brandDna),
        visual_dna: parseJson('visual_dna', visualDna),
        campaign_context: parseJson('campaign_context', campaignContext),
      };
      setResult(await generateHiDreamCommercialVisual(finalPayload));
    } catch (e: any) {
      setError(e.message || 'Request failed');
    } finally { setLoading(false); }
  }

  const update = (key: keyof HiDreamGenerateRequest, value: any) => setPayload({...payload, [key]: value});

  return <main className="page">
    <section className="hero">
      <div>
        <p className="eyebrow">V27 — HiDream Commercial Visual Engine</p>
        <h1>Premium Commercial Rendering Layer</h1>
        <p className="sub">Creative Context Graph → Prompt Compiler → HiDream Provider → Artifact Contract → Perception Scoring → Storyboard Expansion → Winner DNA.</p>
      </div>
      <div className="law-card"><b>Provider</b><span>{payload.provider}</span></div>
    </section>

    <section className="grid two">
      <div className="card">
        <h2>Business + Creative Input</h2>
        <label className="field"><span>business_goal</span><input value={payload.business_goal} onChange={e=>update('business_goal', e.target.value)} /></label>
        <label className="field"><span>industry</span><input value={payload.industry} onChange={e=>update('industry', e.target.value)} /></label>
        <label className="field"><span>product_name</span><input value={payload.product_name} onChange={e=>update('product_name', e.target.value)} /></label>
        <label className="field"><span>audience</span><input value={payload.audience || ''} onChange={e=>update('audience', e.target.value)} /></label>
        <label className="field"><span>copy_text</span><input value={payload.copy_text || ''} onChange={e=>update('copy_text', e.target.value)} /></label>
        <div className="mini-grid">
          <label className="field"><span>use_case</span><select value={payload.use_case} onChange={e=>update('use_case', e.target.value as any)}>{['beauty_ad','fashion_editorial','cosmetic_product','luxury_perfume','poster','ecommerce','showroom','beauty_avatar','storyboard_keyframe'].map(x=><option key={x}>{x}</option>)}</select></label>
          <label className="field"><span>aspect_ratio</span><select value={payload.aspect_ratio} onChange={e=>update('aspect_ratio', e.target.value as any)}>{['1:1','4:5','3:4','9:16','16:9'].map(x=><option key={x}>{x}</option>)}</select></label>
          <label className="field"><span>render_tier</span><select value={payload.render_tier} onChange={e=>update('render_tier', e.target.value as any)}>{['draft','premium','hero'].map(x=><option key={x}>{x}</option>)}</select></label>
          <label className="field"><span>provider</span><select value={payload.provider} onChange={e=>update('provider', e.target.value as any)}>{['mock','hf_inference','local_diffusers'].map(x=><option key={x}>{x}</option>)}</select></label>
        </div>
        <button onClick={submit} disabled={loading}>{loading ? 'Đang render qua V27...' : 'Generate Premium Visual'}</button>
        {error && <p className="error">{error}</p>}
      </div>
      <div className="card">
        <h2>Graph Context JSON</h2>
        <label className="field"><span>brand_dna</span><textarea value={brandDna} onChange={e=>setBrandDna(e.target.value)} /></label>
        <label className="field"><span>visual_dna</span><textarea value={visualDna} onChange={e=>setVisualDna(e.target.value)} /></label>
        <label className="field"><span>campaign_context</span><textarea value={campaignContext} onChange={e=>setCampaignContext(e.target.value)} /></label>
      </div>
    </section>

    {result && <section className="grid two">
      <div className="card">
        <h2>Artifact</h2>
        {result.artifact?.url && <img className="preview" src={result.artifact.url.startsWith('/artifacts') ? `http://localhost:8000${result.artifact.url}` : result.artifact.url} />}
        <pre>{JSON.stringify(result.artifact, null, 2)}</pre>
      </div>
      <div className="card"><h2>Score + Promotion Gate</h2><pre>{JSON.stringify({score: result.score, promotion_gate: result.promotion_gate, memory_update: result.memory_update}, null, 2)}</pre></div>
      <div className="card"><h2>Prompt Contract</h2><pre>{JSON.stringify(result.prompt_contract, null, 2)}</pre></div>
      <div className="card"><h2>Storyboard Expansion</h2>{result.storyboard_expansion?.scenes?.map((s:any)=><div className="mini" key={s.scene}><b>Scene {s.scene}: {s.role}</b><p>{s.visual}</p><p>{s.motion} — {s.duration_sec}s</p></div>)}</div>
    </section>}
  </main>
}
