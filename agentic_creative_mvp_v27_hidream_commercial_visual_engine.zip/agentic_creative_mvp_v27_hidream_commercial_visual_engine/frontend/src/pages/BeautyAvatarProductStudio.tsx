import React, { useState } from 'react';
import { runProductHoldingAvatar, ProductHoldingAvatarRequest } from '../lib/api';

const defaultPayload: ProductHoldingAvatarRequest = {
  industry: 'cosmetic brand',
  product_name: 'Luxury Rose Lipstick',
  product_type: 'lipstick',
  brand_name: 'Demo Beauty',
  target_channel: 'tiktok',
  avatar_gender: 'female',
  outfit_type: 'tshirt',
  product_motion_goal: 'hold near lips, demonstrate color payoff, CTA',
  campaign_goal: 'increase trust, product desire, and conversion',
};

export default function BeautyAvatarProductStudio() {
  const [payload, setPayload] = useState<ProductHoldingAvatarRequest>(defaultPayload);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function submit() {
    setLoading(true); setError('');
    try {
      setResult(await runProductHoldingAvatar(payload));
    } catch (e: any) {
      setError(e.message || 'Request failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page">
      <section className="hero">
        <p className="eyebrow">V26.2 Product Holding Try-On Avatar Engine</p>
        <h1>AI Beauty Avatar Product Studio</h1>
        <p>Biến avatar thành người mẫu ảo/KOL ảo có thể cầm, dùng thử và giới thiệu sản phẩm bằng ảnh + video.</p>
      </section>

      <section className="grid two">
        <div className="card">
          <h2>Input</h2>
          {(['industry','product_name','product_type','brand_name','product_motion_goal','campaign_goal'] as const).map((key) => (
            <label key={key} className="field">
              <span>{key}</span>
              <input value={(payload as any)[key] || ''} onChange={(e) => setPayload({...payload, [key]: e.target.value})} />
            </label>
          ))}
          <label className="field">
            <span>target_channel</span>
            <select value={payload.target_channel} onChange={(e) => setPayload({...payload, target_channel: e.target.value as any})}>
              {['poster','tiktok','reel','livestream','landing','ecommerce','campaign'].map(v => <option key={v}>{v}</option>)}
            </select>
          </label>
          <label className="field">
            <span>outfit_type</span>
            <select value={payload.outfit_type} onChange={(e) => setPayload({...payload, outfit_type: e.target.value as any})}>
              {['tshirt','bikini','fashion','wedding_dress','spa_uniform','lookbook'].map(v => <option key={v}>{v}</option>)}
            </select>
          </label>
          <button onClick={submit} disabled={loading}>{loading ? 'Đang chạy...' : 'Generate Avatar Product Plan'}</button>
          {error && <p className="error">{error}</p>}
        </div>

        <div className="card">
          <h2>Core Engines</h2>
          <ul className="checks">
            <li>Facial Consistency Engine</li>
            <li>Body Language Presenter Engine</li>
            <li>Beauty Perception Scoring</li>
            <li>Natural Curve Engine</li>
            <li>Fashion Perception Engine</li>
            <li>Camera & Pose Engine</li>
            <li>Fabric Physics Engine</li>
            <li>Body Beauty Perception Graph</li>
          </ul>
        </div>
      </section>

      {result && (
        <section className="grid two">
          <div className="card">
            <h2>Body Language Plan</h2>
            {result.body_language_plan.map((item: any) => (
              <div className="mini" key={item.step}>
                <strong>{item.step}. {item.name}</strong>
                <p>Eyes: {item.eyes}</p>
                <p>Hands: {item.hands}</p>
                <p>Movement: {item.movement}</p>
              </div>
            ))}
          </div>
          <div className="card">
            <h2>Poster Prompt</h2>
            <pre>{result.poster_prompt}</pre>
            <h2>QA Contract</h2>
            <ul className="checks">{result.qa_contract.must_pass.map((x: string) => <li key={x}>{x}</li>)}</ul>
          </div>
        </section>
      )}
    </main>
  );
}
