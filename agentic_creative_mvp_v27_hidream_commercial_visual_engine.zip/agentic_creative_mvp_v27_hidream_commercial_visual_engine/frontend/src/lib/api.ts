const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api/v1';

export type DesignRequest = {
  industry: string;
  product: string;
  audience: string;
  channel: string;
  goal: string;
  brand_name: string;
  tone?: string;
  budget_tier?: 'low' | 'mid' | 'premium';
  language?: string;
};

export async function runDesignStudio(payload: DesignRequest) {
  const res = await fetch(`${API_BASE}/design-studio/run`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function getOperatingLaw() {
  const res = await fetch(`${API_BASE}/governance/operating-law`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export type ProductHoldingAvatarRequest = {
  industry: string;
  product_name: string;
  product_type: string;
  brand_name?: string;
  target_channel?: 'poster' | 'tiktok' | 'reel' | 'livestream' | 'landing' | 'ecommerce' | 'campaign';
  avatar_gender?: 'female' | 'male' | 'non_binary';
  avatar_style?: string;
  outfit_type?: 'tshirt' | 'bikini' | 'fashion' | 'wedding_dress' | 'spa_uniform' | 'lookbook';
  product_motion_goal?: string;
  campaign_goal?: string;
  language?: string;
};

export async function runProductHoldingAvatar(payload: ProductHoldingAvatarRequest) {
  const res = await fetch(`${API_BASE}/beauty-avatar/product-holding`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}


export type HiDreamGenerateRequest = {
  business_goal: string;
  industry: string;
  product_name: string;
  audience?: string;
  use_case?: 'beauty_ad' | 'fashion_editorial' | 'cosmetic_product' | 'luxury_perfume' | 'poster' | 'ecommerce' | 'showroom' | 'beauty_avatar' | 'storyboard_keyframe';
  brand_dna?: Record<string, any>;
  visual_dna?: Record<string, any>;
  campaign_context?: Record<string, any>;
  copy_text?: string;
  aspect_ratio?: '1:1' | '4:5' | '3:4' | '9:16' | '16:9';
  render_tier?: 'draft' | 'premium' | 'hero';
  provider?: 'mock' | 'hf_inference' | 'local_diffusers';
  enable_typography_safe_mode?: boolean;
  enable_storyboard_expansion?: boolean;
  enable_8k_export_contract?: boolean;
};

export async function generateHiDreamCommercialVisual(payload: HiDreamGenerateRequest) {
  const res = await fetch(`${API_BASE}/hidream/commercial-visual/generate`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
