import React from 'react';
import { createRoot } from 'react-dom/client';
import DesignStudio from './pages/DesignStudio';
import BeautyAvatarProductStudio from './pages/BeautyAvatarProductStudio';
import HiDreamCommercialStudio from './pages/HiDreamCommercialStudio';
import './styles.css';

function App() {
  const path = window.location.pathname;
  if (path.includes('hidream-commercial')) return <HiDreamCommercialStudio />;
  if (path.includes('beauty-avatar-product')) return <BeautyAvatarProductStudio />;
  return <DesignStudio />;
}

createRoot(document.getElementById('root')!).render(<App />);
