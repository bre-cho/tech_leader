# V26.2 — Product Holding Try-On Avatar Engine

Module này bổ sung vào V26 để biến avatar thành người mẫu ảo/KOL ảo có thể cầm, dùng thử và giới thiệu sản phẩm bằng ảnh + video.

## Core idea

Không chỉ tạo avatar đứng yên cầm sản phẩm. Avatar phải có ngôn ngữ cơ thể như chuyên gia thuyết trình:

- Ánh mắt nhìn theo hướng di chuyển của sản phẩm.
- Không đứng thẳng một chỗ trong toàn bộ video.
- Có nụ cười tự nhiên, cử chỉ tay, xoay người nhẹ, đưa sản phẩm gần/xoay sản phẩm về camera.
- Giữ tính thuyết phục: tự tin, thu hút, thân thiện, commercial-realistic.

## Brand-safe default avatar rule

Mặc định avatar là nữ, adult-looking, phong cách beauty KOL thương mại. Trang phục mặc định là áo phông fitted thương mại, có neckline vừa phải, nhấn vào dáng tự nhiên và tính thời trang. Hệ thống dùng `Natural Curve Engine` để tạo silhouette chân thực, không tạo anatomy phi thực tế, không plastic body, không over-inflated proportions.

## Engines added

1. Facial Consistency Engine
2. Beauty Perception Scoring
3. Compound Beauty Memory
4. Natural Curve Engine
5. Fashion Perception Engine
6. Camera & Pose Engine
7. Fabric Physics Engine
8. Body Beauty Perception Graph
9. Product Holding Try-On Engine
10. Body Language Presenter Engine

## API

```http
POST /api/beauty-avatar/product-holding
```

Example payload:

```json
{
  "industry": "cosmetic brand",
  "product_name": "Luxury Rose Lipstick",
  "product_type": "lipstick",
  "brand_name": "Demo Beauty",
  "target_channel": "tiktok",
  "avatar_gender": "female",
  "outfit_type": "tshirt",
  "product_motion_goal": "hold near lips, demonstrate color payoff, CTA",
  "campaign_goal": "increase trust, product desire, and conversion"
}
```

## Required QA

- Same face / identity / beauty DNA across image, video, campaign.
- Product not deformed, product label readable.
- Natural hands and no finger distortion.
- Gaze follows product motion.
- Avatar has presenter-like motion, not stiff standing.
- Fabric physics plausible.
- Realistic anatomy and brand-safe fashion framing.
- Beauty perception score included.
- Body Beauty Perception Graph included.

## System integrations

- Beauty Perception Intelligence
- Color Intelligence Graph
- Blend Retouch Engine
- Restore Photo Engine
- Fashion Uniform Builder
- 3D Brand Space Builder
- Creative Execution Graph
- 8K Upscale Runtime
- Brand Memory Cloud
- Winner DNA Engine
