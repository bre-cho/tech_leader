# V27 — HiDream Commercial Visual Engine

## Mục tiêu

Bổ sung một premium rendering layer cho MVP: không dùng HiDream như một model ảnh đơn lẻ, mà đưa vào runtime theo đúng luật vận hành:

`TARGET_DEFINE → RESEARCH → PLAN → EXECUTE → VERIFY → DISTILL_TO_SKILL → MEMORY_UPDATE → WINNER_DNA_UPDATE`

## Endpoint

```bash
POST /api/v1/hidream/commercial-visual/generate
```

## Providers

- `mock`: tạo PNG thật để dev/CI chạy không cần GPU.
- `hf_inference`: gọi Hugging Face Inference API. Cần `HUGGINGFACE_TOKEN`.
- `local_diffusers`: chạy local qua `diffusers`. Cần GPU/torch/diffusers và model tương thích.

ENV:

```bash
HIDREAM_PROVIDER=mock
HIDREAM_MODEL_ID=HiDream-ai/HiDream-O1-Image
HUGGINGFACE_TOKEN=...
ARTIFACT_DIR=./artifacts
```

## Cách chạy nhanh

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Test:

```bash
curl -X POST http://localhost:8000/api/v1/hidream/commercial-visual/generate \
  -H 'Content-Type: application/json' \
  -d '{
    "business_goal":"Create a premium cosmetic poster that can become a product showcase video",
    "industry":"cosmetic beauty",
    "product_name":"Luminous Serum",
    "audience":"young professional women",
    "use_case":"cosmetic_product",
    "provider":"mock",
    "brand_dna":{"palette":"champagne gold, ivory, soft black"},
    "visual_dna":{"materials":"glass serum bottle, glowing skin, silk fabric"},
    "campaign_context":{"offer":"launch bundle"}
  }'
```

## Luồng vận hành thật

1. Request vào API.
2. `HiDreamPromptCompiler` biên dịch business context thành prompt contract.
3. Provider render ảnh.
4. `ArtifactStore` lưu PNG + replay contract + checksum.
5. `CommercialPerceptionScorer` chấm commercial/luxury/texture/typography/storyboard readiness.
6. `PromotionGate` block/promote dựa trên artifact + score + workflow trace.
7. Nếu đạt winner, ghi Winner DNA.
8. Trả storyboard expansion để nối sang video factory.

## File chính

```text
backend/app/schemas/hidream.py
backend/app/hidream/prompt_compiler.py
backend/app/hidream/provider.py
backend/app/hidream/artifacts.py
backend/app/hidream/scoring.py
backend/app/hidream/storyboard.py
backend/app/hidream/service.py
backend/tests/test_hidream_v27.py
frontend/src/pages/HiDreamCommercialStudio.tsx
```

## Không phải bộ khung

Module này đã có:

- API thật
- prompt compiler thật
- provider adapter thật
- artifact file thật
- checksum/replay contract
- scoring logic
- promotion gate
- Winner DNA hook
- storyboard expansion
- frontend page
- test

Để production GPU, dev chỉ cần thay `HIDREAM_PROVIDER=local_diffusers` hoặc custom provider trong `provider.py`.
