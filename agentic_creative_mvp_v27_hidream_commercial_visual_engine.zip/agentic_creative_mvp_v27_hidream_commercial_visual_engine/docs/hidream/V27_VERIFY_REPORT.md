# V27 Verify Report

## Completed

- Added operational backend API: `POST /api/v1/hidream/commercial-visual/generate`.
- Added HiDream prompt compiler.
- Added provider adapters: `mock`, `hf_inference`, `local_diffusers`.
- Added artifact storage with SHA256 checksum and replay contract.
- Added commercial perception scoring.
- Added promotion gate + workflow trace enforcement.
- Added Winner DNA integration hook.
- Added storyboard expansion for poster-to-video pipeline.
- Added frontend page: `/hidream-commercial`.
- Added docs and pytest test file.

## Local sandbox validation

- `python -m compileall app`: PASS.
- `pytest`: not executed successfully in sandbox because the current Python environment is missing project dependencies such as `sqlalchemy`. Dev should run after `pip install -r backend/requirements.txt`.

## Production note

Default provider is `mock` so MVP can run without GPU. For real HiDream generation, set either:

```bash
HIDREAM_PROVIDER=hf_inference
HUGGINGFACE_TOKEN=...
```

or:

```bash
HIDREAM_PROVIDER=local_diffusers
HIDREAM_MODEL_ID=HiDream-ai/HiDream-O1-Image
```

and install torch/diffusers compatible with the target GPU environment.
