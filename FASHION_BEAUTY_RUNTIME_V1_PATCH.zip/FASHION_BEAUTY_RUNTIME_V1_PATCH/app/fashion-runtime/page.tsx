import { FashionRuntimeStudio } from '@/components/fashion-runtime/FashionRuntimeStudio'
import './fashion-runtime.css'

export default function FashionRuntimePage() {
  return <FashionRuntimeStudio />
}
