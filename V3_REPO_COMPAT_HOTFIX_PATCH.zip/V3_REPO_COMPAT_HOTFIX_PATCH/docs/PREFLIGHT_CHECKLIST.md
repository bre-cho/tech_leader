# PREFLIGHT CHECKLIST

## Backend
- [ ] `backend/app/movie_os` exists.
- [ ] `backend/app/api/v1/movie_os.py` exists.
- [ ] `main.py` includes `movie_os_router`.
- [ ] `POST /api/v1/movie-os/direct` returns JSON.

## Next.js
- [ ] `app/movie-director-v3/page.tsx` exists.
- [ ] `app/api/v1/movie-os/[...path]/route.ts` exists.
- [ ] `components/movie-os-v3/MovieDirectorSystemV3.tsx` exists.
- [ ] `lib/movie-os-v3-api.ts` calls `/api/v1/movie-os/direct`.
- [ ] No direct browser call to `localhost:8000`.

## Vite
- [ ] `frontend/src/pages/MovieStudioV3.tsx` exists.
- [ ] `frontend/src/movie-os-v3/runtime/movieHandoffReceiver.ts` import is valid.
- [ ] `main.tsx` has `movie_handoff` branch.
- [ ] `MovieStudioV3` renders when URL has `movie_handoff`.

## Runtime
- [ ] Open Movie Studio V3 button opens `5173?movie_handoff=...`
- [ ] Vite renders storyboard scene list.
- [ ] Sequential render state works.
