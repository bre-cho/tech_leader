# V3_REPO_COMPAT_HOTFIX_PATCH

## Mục tiêu

Sửa patch `UIUX_V3_CINEMATIC_DIRECTOR_SYSTEM` để tương thích với repo hiện tại.

## Các lỗi đã fix

### Critical
- Backend router chuyển về đúng cấu trúc `backend/app/api/v1/movie_os.py`.
- Có hướng dẫn include router trong `main.py`.

### Critical
- Vite có file mount/runtime để nhận `movie_handoff` và render `MovieStudioV3`.

### High
- Fix import path Vite: không dùng `../../../types/...` đi ra ngoài `src`.

### High
- Next dùng proxy relative path `/api/v1/movie-os/direct`, không gọi thẳng `localhost:8000`.

### Medium
- `MovieDirectorSystemV3.tsx` gọi backend thật qua `directMovie()`.
- Local mock chỉ còn fallback khi API lỗi nếu dev bật thủ công.

## Cấu trúc patch

```text
backend/app/api/v1/movie_os.py
backend/app/movie_os/
app/api/v1/movie-os/[...path]/route.ts
app/movie-director-v3/
components/movie-os-v3/
types/movie-os-v3.ts
lib/movie-os-v3-api.ts
frontend/src/pages/MovieStudioV3.tsx
frontend/src/movie-os-v3/runtime/movieHandoffReceiver.ts
frontend/src/movie-os-v3/runtime/MovieStudioV3Mount.tsx
frontend/src/types/movie-os-v3.ts
frontend/src/styles/movie-os-v3.css
docs/
```
