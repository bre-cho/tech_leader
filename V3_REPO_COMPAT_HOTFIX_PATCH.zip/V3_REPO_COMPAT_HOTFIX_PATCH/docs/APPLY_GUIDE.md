# APPLY GUIDE

## 1. Backend

Copy:

```bash
cp -r backend/app/movie_os <repo>/backend/app/
cp backend/app/api/v1/movie_os.py <repo>/backend/app/api/v1/movie_os.py
```

Trong `backend/app/main.py` hoặc nơi app đang include router:

```python
from app.api.v1.movie_os import router as movie_os_router
app.include_router(movie_os_router, prefix="/api/v1")
```

Nếu repo đang dùng `api_router`, include trong router tập trung:

```python
api_router.include_router(movie_os_router)
```

## 2. Next.js

Copy:

```bash
cp -r app/movie-director-v3 <repo>/app/
cp -r app/api/v1/movie-os <repo>/app/api/v1/
cp -r components/movie-os-v3 <repo>/components/
cp types/movie-os-v3.ts <repo>/types/
cp lib/movie-os-v3-api.ts <repo>/lib/
```

Mở:

```text
http://localhost:3000/movie-director-v3
```

## 3. Vite

Copy:

```bash
cp frontend/src/pages/MovieStudioV3.tsx <repo>/frontend/src/pages/
cp -r frontend/src/movie-os-v3 <repo>/frontend/src/
cp frontend/src/types/movie-os-v3.ts <repo>/frontend/src/types/
cp frontend/src/styles/movie-os-v3.css <repo>/frontend/src/styles/
```

### Cách mount vào `frontend/src/main.tsx`

Thêm import:

```tsx
import MovieStudioV3 from './pages/MovieStudioV3'
```

Sau đó trước render mặc định:

```tsx
const params = new URLSearchParams(window.location.search)

if (params.has('movie_handoff')) {
  root.render(<MovieStudioV3 />)
} else {
  root.render(<App />)
}
```

Nếu `main.tsx` đang render trực tiếp `DesignStudio`, dùng file mẫu:

```text
frontend/src/movie-os-v3/runtime/MovieStudioV3Mount.tsx
```

để copy logic.

## 4. ENV

Next proxy cần:

```env
BACKEND_API_BASE_URL=http://localhost:8000/api/v1
NEXT_PUBLIC_VIDEO_STUDIO_URL=http://localhost:5173
```

Không dùng `NEXT_PUBLIC_API_BASE_URL` để gọi thẳng backend từ browser nữa.

## 5. Test

```bash
curl -X POST http://localhost:8000/api/v1/movie-os/direct \
  -H "Content-Type: application/json" \
  -d '{"prompt":"dark fantasy queen cinematic trailer","target_duration":60,"provider":"kling","planned_batch_size":6}'
```

Next test:

```text
/movie-director-v3
```

Vite handoff test:

```text
http://localhost:5173/?movie_handoff=<encoded_payload>
```
