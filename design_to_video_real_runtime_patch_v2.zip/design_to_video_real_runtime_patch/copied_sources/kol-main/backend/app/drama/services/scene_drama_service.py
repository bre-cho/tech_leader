from __future__ import annotations

from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.drama.engines.character_intent_engine import CharacterIntentEngine
from app.drama.engines.power_shift_engine import PowerShiftEngine
from app.drama.engines.relationship_engine import RelationshipEngine
from app.drama.engines.subtext_engine import SubtextEngine
from app.drama.engines.tension_engine import TensionEngine
from app.drama.models.drama_character_profile import DramaCharacterProfile
from app.drama.models.drama_relationship_edge import DramaRelationshipEdge


class SceneDramaService:
    """Orchestrates phase-2 scene analysis.

    Scene states are persisted via the scene_drama_worker and route handlers.
    """

    def __init__(self, db: Session) -> None:
        self.db = db
        self.intent_engine = CharacterIntentEngine()
        self.relationship_engine = RelationshipEngine()
        self.tension_engine = TensionEngine()
        self.subtext_engine = SubtextEngine()
        self.power_shift_engine = PowerShiftEngine()

    def _load_profiles(self, character_ids: List[UUID]) -> List[DramaCharacterProfile]:
        return (
            self.db.query(DramaCharacterProfile)
            .filter(DramaCharacterProfile.id.in_(character_ids))
            .all()
        )

    def _load_edges(self, project_id: UUID, character_ids: List[UUID]) -> List[DramaRelationshipEdge]:
        return (
            self.db.query(DramaRelationshipEdge)
            .filter(DramaRelationshipEdge.project_id == project_id)
            .filter(DramaRelationshipEdge.source_character_id.in_(character_ids))
            .filter(DramaRelationshipEdge.target_character_id.in_(character_ids))
            .all()
        )

    def analyze_scene(
        self,
        project_id: UUID,
        scene_id: UUID,
        character_ids: List[UUID],
        scene_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        scene_context = scene_context or {}
        profiles = self._load_profiles(character_ids)
        edges = self._load_edges(project_id, character_ids)
        graph_index = self.relationship_engine.build_graph_index(edges)

        # Build participants from loaded profiles so blocking/camera engines get real data.
        participants = [
            {
                "character_id": str(profile.id),
                "name": profile.name,
                "archetype": profile.archetype,
            }
            for profile in profiles
        ]

        # Infer dominant character before engine calls so power_shift_engine can use it.
        # Priority: explicit caller value → graph-inferred → first loaded profile (fallback for
        # scenes with no relationship edges yet).
        effective_dominant_id = (
            scene_context.get("dominant_character_id")
            or infer_dominant_character(graph_index)
            or (str(profiles[0].id) if profiles else None)
        )

        scene_context = {
            **scene_context,
            "participants": scene_context.get("participants", participants),
            "dominant_character_id": effective_dominant_id,
        }

        intents = [self.intent_engine.derive(profile, scene_context) for profile in profiles]
        tension = self.tension_engine.score(intents, graph_indexed_edges(graph_index), scene_context)

        subtext_map: List[Dict[str, Any]] = []
        for speaker in profiles:
            for target in profiles:
                if speaker.id == target.id:
                    continue
                forward = graph_index.get(str(speaker.id), {}).get(str(target.id))
                subtext_map.append(
                    self.subtext_engine.infer_dialogue_actions(
                        speaker_profile=speaker,
                        target_profile=target,
                        relationship_forward=forward,
                        scene_context=scene_context,
                    )
                )

        power_shift = self.power_shift_engine.compute(scene_context, graph_indexed_edges(graph_index))

        # Build threatened_character_id: explicit caller value → engine result → second profile.
        threatened_character_id = (
            scene_context.get("threatened_character_id")
            or power_shift.get("threatened_character_id")
            or next((str(p.id) for p in profiles if str(p.id) != effective_dominant_id), None)
        )

        # Enrich power_shift with keys consumed by BlockingEngine and CameraDramaEngine.
        power_shift = {
            **power_shift,
            "dominant_character_id": effective_dominant_id,
            "threatened_character_id": threatened_character_id,
            "outcome_type": scene_context.get("outcome_type", "scene_shift"),
        }

        # Build tension_breakdown with the keys consumed by blocking/camera engines.
        breakdown = tension.get("breakdown", {})
        tension_breakdown = {
            **breakdown,
            "tension_score": tension.get("tension_score", 0.0),
            "exposure_risk": breakdown.get("emotional_exposure_risk", 0.0),
        }

        drama_state = {
            "tension_score": tension.get("tension_score", 0.0),
            "pressure_level": tension.get("tension_score", 0.0),
            "dominant_character_id": effective_dominant_id,
            "threatened_character_id": threatened_character_id,
            "outcome_type": scene_context.get("outcome_type", "scene_shift"),
            "turning_point": scene_context.get("turning_point"),
            "power_shift_delta": power_shift.get("total_delta", 0.0),
            "trust_shift_delta": 0.0,
            "exposure_shift_delta": 0.0,
            "dependency_shift_delta": 0.0,
        }

        return {
            "project_id": str(project_id),
            "scene_id": str(scene_id),
            "episode_id": str(scene_context.get("episode_id")) if scene_context.get("episode_id") else None,
            "character_count": len(profiles),
            "intents": [intent.__dict__ for intent in intents],
            "tension": tension,
            "subtext_map": subtext_map,
            "power_shift": power_shift,
            "dominant_character_id": effective_dominant_id,
            "drama_state": drama_state,
            "tension_breakdown": tension_breakdown,
            "relationship_snapshot": graph_index,
            "relationship_shifts": power_shift.get("relationship_shifts", []),
            "scene_context": scene_context,
            "status": "analyzed",
        }


def graph_indexed_edges(graph_index: Dict[str, Dict[str, Any]]) -> List[Any]:
    edges: List[Any] = []
    for targets in graph_index.values():
        edges.extend(targets.values())
    return edges


def infer_dominant_character(graph_index: Dict[str, Dict[str, Any]]) -> Optional[str]:
    scores: Dict[str, float] = {}
    for source_id, targets in graph_index.items():
        scores.setdefault(source_id, 0.0)
        for snapshot in targets.values():
            scores[source_id] += float(getattr(snapshot, "dominance_source_over_target", 0.0) or 0.0)
    if not scores:
        return None
    return max(scores, key=scores.get)
