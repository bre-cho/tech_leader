from __future__ import annotations

from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class SceneDramaAnalyzeRequest(BaseModel):
    project_id: UUID
    scene_id: UUID
    character_ids: List[UUID] = Field(min_length=2)
    scene_context: Optional[Dict[str, Any]] = None


class AnalyzeSceneRequest(SceneDramaAnalyzeRequest):
    """OpenAPI-compatible alias."""


class CompileSceneRequest(BaseModel):
    project_id: UUID
    episode_id: UUID | None = None
    scene_context: Dict[str, Any] = Field(default_factory=dict)
    scene_analysis: Dict[str, Any] = Field(default_factory=dict)
    previous_scene_state: Optional[Dict[str, Any]] = None
    character_arc_state: Optional[Dict[str, Any]] = None


class ApplySceneOutcomeRequest(BaseModel):
    project_id: UUID
    episode_id: UUID | None = None
    scene_id: UUID
    outcome_type: str
    turning_point: str | None = None
    trust_shift_delta: float = 0.0
    exposure_shift_delta: float = 0.0
    dependency_shift_delta: float = 0.0
    recompute_downstream: bool = True


class SceneIntentRead(BaseModel):
    character_id: str
    outer_goal: Optional[str] = None
    hidden_need: Optional[str] = None
    fear_trigger: Optional[str] = None
    mask_strategy: Optional[str] = None
    likely_scene_intent: str
    pressure_response: Optional[str] = None
    notes: List[str] = Field(default_factory=list)


class SceneTensionRead(BaseModel):
    tension_score: float
    breakdown: Dict[str, float]
    flat_scene: bool


class SceneDramaAnalyzeResponse(BaseModel):
    project_id: str
    scene_id: str
    episode_id: Optional[str] = None
    character_count: int
    intents: List[Dict[str, Any]]
    tension: Dict[str, Any]
    subtext_map: List[Dict[str, Any]]
    power_shift: Dict[str, Any]
    dominant_character_id: Optional[str] = None
    drama_state: Optional[Dict[str, Any]] = None
    tension_breakdown: Optional[Dict[str, Any]] = None
    relationship_snapshot: Optional[Dict[str, Any]] = None
    relationship_shifts: Optional[List[Any]] = None
    scene_context: Optional[Dict[str, Any]] = None
    status: str
