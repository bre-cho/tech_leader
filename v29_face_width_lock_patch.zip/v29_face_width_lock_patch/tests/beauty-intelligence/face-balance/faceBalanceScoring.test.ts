import { enhancePromptWithFaceWidthLock, scoreFaceBalancePrompt } from "../../../src/lib/beauty-intelligence/face-balance";

describe("Face Width Lock", () => {
  it("adds anti-pointed-chin prompt terms", () => {
    const result = enhancePromptWithFaceWidthLock({
      basePrompt: "adult virtual Korean beauty influencer, soft compact oval face shape",
      negativePrompt: "",
      provider: "flux",
      strictGate: true
    });

    expect(result.prompt).toContain("soft rounded compact face");
    expect(result.prompt).toContain("natural chin base width retention");
    expect(result.prompt).toContain("soft lower-face width continuity");
    expect(result.prompt).toContain("rounded blunt chin");
    expect(result.negativePrompt).toContain("sharp chin tip");
    expect(result.negativePrompt).toContain("pinched chin base");
    expect(result.score.total).toBeGreaterThanOrEqual(80);
    expect(result.gatePassed).toBe(true);
  });

  it("scores weak face prompt lower", () => {
    const score = scoreFaceBalancePrompt("beautiful Korean face, V-line", "");
    expect(score.total).toBeLessThan(70);
  });
});
