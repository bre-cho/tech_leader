# V29 — Face Width Lock Patch

Fix lỗi cằm nhọn / V-line AI cho MVP Beauty KOL.

## Cách tích hợp vào pipeline

```ts
import { enhancePromptWithFaceWidthLock } from "@/lib/beauty-intelligence/face-balance";

const faceFixed = enhancePromptWithFaceWidthLock({
  basePrompt: scene.prompt,
  negativePrompt: scene.negativePrompt,
  provider: selectedProvider,
  strictGate: true,
});

if (!faceFixed.gatePassed) {
  throw new Error("Face balance score thấp: có nguy cơ cằm nhọn / V-line AI.");
}

scene.prompt = faceFixed.prompt;
scene.negativePrompt = faceFixed.negativePrompt;
scene.metadata = {
  ...scene.metadata,
  faceBalance: faceFixed.score,
  faceModules: faceFixed.appliedModules,
};
```

## Positive terms chính
soft rounded compact face, soft U-shape face structure, natural chin base width retention, soft lower-face width continuity, gentle jaw width preservation, balanced lower-face width distribution, rounded blunt chin, softly flattened chin tip, non-pointed chin structure.

## Negative terms chính
sharp chin tip, pointed chin, aggressive V-line, triangular chin, needle chin, pinched chin base, collapsed lower face, over-tapered jaw, narrow jaw base, compressed chin width.
